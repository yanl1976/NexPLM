// 文档通用
var DocumentCommon = 
    {
        title: "通用",
        id: "SView-settingDocumentCommon",
        subComponents: [
            {
                CollapseItem: {
                    id: "observeMode",
                    label: "观察模式",
                    subComponents: [
                        {
                            Select: {
                                value: 3,
                                id: "observeModeSelect",
                                options: [
                                    {
                                        Option: {
                                            value: 3,
                                            content: "自由观察",
                                        }
                                    },
                                    {
                                        Option: {
                                            value: 1,
                                            content: "动态观察",
                                        }
                                    },
                                    {
                                        Option: {
                                            value: 2,
                                            content: "约束观察",
                                        }
                                    }
                                ]
                            }
                        }
                    ]
                },
            },
            {
                CollapseItem: {
                    id: "upDirection",
                    label: "向上方向",
                    subComponents: [
                        {
                            Select: {
                                id: "upDirectionSelect",
                                //onClick: "upDirection()",
                                options: [
                                    {
                                        Option: {
                                            value: 0,
                                            content: "+x",
                                        }
                                    },
                                    {
                                        Option: {
                                            value: 1,
                                            content: "-x",
                                        }
                                    },
                                    {
                                        Option: {
                                            value: 2,
                                            content: "+y",
                                            selected: "selected"
                                        }
                                    },
                                    {
                                        Option: {
                                            value: 3,
                                            content: "-y",
                                        }
                                    },
                                    {
                                        Option: {
                                            value: 4,
                                            content: "+z",
                                        }
                                    },
                                    {
                                        Option: {
                                            value: 5,
                                            content: "-z",
                                        }
                                    }
                                ]
                            }
                        }
                    ],
                },
            },
            {
                CollapseItem: {
                    id: "perspectiveView",
                    label: "透视投影",
                    subComponents: [
                        {
                            Switch: {
                                checkboxId: "perspectiveViewSwitch",
                                checked:false,
                                label: {
                                    inner: {
                                        dataOn: "ON",
                                        dataOff: "OFF",
                                    },
                                }
                            }
                        }
                    ]
                },
            },
            {
                CollapseItem: {
                    id: "selectEffect",
                    label: "选中效果",
                    subComponents: [
                        {
                            Select: {
                                id: "selectEffectSelect",
                                //onClick: "selectEffect()",
                                options: [
                                    {
                                        Option: {
                                            value: 0,
                                            content: "轮廓",
                                        }
                                    },
                                    {
                                        Option: {
                                            value: 1,
                                            content: "高亮",
                                        }
                                    },
                                    {
                                        Option: {
                                            value: 2,
                                            content: "突出显示",
                                        }
                                    },
                                ]
                            }
                        }
                    ]
                }
            },
            {
                CollapseItem: {
                    id: "setBackground",
                    label: "背景",
                    subComponents: [
                        {
                            Button: {
                                id: "bgSelect",
                                imgsrc: "images/background/white.png",
                                onClick: "showPopoverSelect('bgPopoverSelect')",
                                subComponents: [
                                    {
                                        PopoverSelect: {
                                            id: "bgPopoverSelect",
                                            isShow: false,
                                            classes: [
                                                "SView-popoverSelect",
                                                "SView-popoverSelect-down",
                                                "SView-popoverSelect-tripleWidth",
                                                "SView-popoverSelect-background"
                                            ],
                                            subComponents: [
                                                {
                                                    Button: {
                                                        id: "background_1",
                                                        imgsrc: "images/background/white.png",
                                                        onClick: "popoverSelectImg('bgSelect', 'background_1')"
                                                    },
                                                },
                                                {
                                                    Button: {
                                                        id: "background_2",
                                                        imgsrc: "images/background/black.png",
                                                        onClick: "popoverSelectImg('bgSelect', 'background_2')"
                                                    },
                                                },
                                                {
                                                    Button: {
                                                        id: "background_3",
                                                        imgsrc: "images/background/179.179.192.png",
                                                        onClick: "popoverSelectImg('bgSelect', 'background_3')"
                                                    },
                                                },
                                                {
                                                    Button: {
                                                        id: "background_4",
                                                        imgsrc: "images/background/234.234.234.png",
                                                        onClick: "popoverSelectImg('bgSelect', 'background_4')"
                                                    },
                                                },
                                                {
                                                    Button: {
                                                        id: "background_5",
                                                        imgsrc: "images/background/236-248-255.png",
                                                        onClick: "popoverSelectImg('bgSelect', 'background_5')"
                                                    },
                                                },
                                                {
                                                    Button: {
                                                        id: "background_6",
                                                        imgsrc: "images/background/148.202.239-255.255.255.png",
                                                        onClick: "popoverSelectImg('bgSelect', 'background_6')"
                                                    },
                                                },
                                                {
                                                    Button: {
                                                        id: "background_7",
                                                        imgsrc: "images/background/128.128.128-240.240.240.png",
                                                        onClick: "popoverSelectImg('bgSelect', 'background_7')"
                                                    },
                                                },
                                                {
                                                    Button: {
                                                        id: "background_8",
                                                        imgsrc: "images/background/230.230.230-170.170.170.png",
                                                        onClick: "popoverSelectImg('bgSelect', 'background_8')"
                                                    },
                                                },
                                                {
                                                    Button: {
                                                        id: "background_9",
                                                        imgsrc: "images/background/defaultcolor.png",
                                                        onClick: "popoverSelectImg('bgSelect', 'background_9')"
                                                    },
                                                }
                                            ]
                                        }
                                    }
                                ]
                            }
                        }
                    ],
                }
            },
        ]
    }


// 文档漫游
var DocumentWalking = {
    title: "漫游",
    id: "SView-settingDocumentWalking",
    subComponents: [
        {
            CollapseItem: {
                id: "roaming",
                label: "漫游",
                subComponents: [{
                    Switch: {
                        checkboxId: "roamingSwitch",
                        checked: false,
                        label: {
                            inner: {
                                dataOn: "ON",
                                dataOff: "OFF",
                            },
                        }
                    }
                }]
            }
        },
        {
            CollapseItem: {
                id: "roamingSpeed",
                label: "速度",
                subComponents: [{
                    Select: {
                        id: "roamingSpeedSelect",
                        onClick: "roamingSpeedSelect()",
                        value: null,
                        options: [
                            {
                                Option: {
                                    value: 0,
                                    content: "0.05x",
                                }
                            },
                            {
                                Option: {
                                    value: 1,
                                    content: "0.25x",
                                }
                            },
                            {
                                Option: {
                                    value: 2,
                                    content: "0.5x",
                                }
                            },
                            {
                                Option: {
                                    value: "3",
                                    content: "0.75x",
                                }
                            },
                            {
                                Option: {
                                    value: 4,
                                    content: "1x",
                                }
                            },
                            {
                                Option: {
                                    value: 5,
                                    content: "2x",
                                }
                            },
                            {
                                Option: {
                                    value: 6,
                                    content: "4x",
                                }
                            },
                            {
                                Option: {
                                    value: 7,
                                    content: "6x",
                                }
                            }
                        ]
                    }
                }]
            }
        },
        {
            CollapseItem: {
                id: "viewSize",
                label: "视野大小",
                subComponents: [{
                    Select: {
                        id: "viewSizeSelect",
                        onClick: "viewSizeSelect()",
                        value: null,
                        options: [
                            {
                                Option: {
                                    value: 0,
                                    content: "50°",
                                    selected: "selected"
                                }
                            },
                            {
                                Option: {
                                    value: 1,
                                    content: "60°",
                                }
                            },
                            {
                                Option: {
                                    value: 2,
                                    content: "70°",
                                }
                            },
                            {
                                Option: {
                                    value: 3,
                                    content: "80°",
                                }
                            },
                            {
                                Option: {
                                    value: 4,
                                    content: "90°",
                                }
                            },
                            {
                                Option: {
                                    value: 5,
                                    content: "100°",
                                }
                            },
                            {
                                Option: {
                                    value: 6,
                                    content: "110°",
                                }
                            },
                            {
                                Option: {
                                    value: 7,
                                    content: "120°",
                                }
                            },
                            {
                                Option: {
                                    value: 8,
                                    content: "130°",
                                }
                            },
                            {
                                Option: {
                                    value: 9,
                                    content: "140°",
                                }
                            },
                            {
                                Option: {
                                    value: 10,
                                    content: "150°",
                                }
                            }
                        ]
                    }
                }]
            }
        },
        {
            CollapseItem: {
                id: "virtualButtons",
                label: "虚拟按键",
                subComponents: [{
                    Switch: {
                        checkboxId: "virtualButtonsSwitch",
                        checked: false,
                        label: {
                            inner: {
                                dataOn: "ON",
                                dataOff: "OFF",
                            },
                        }
                    }
                }]
            }
        },
        
        {
            CollapseItem: {
                id: "mouseOperation",
                label: "漫游时鼠标操作",
                subComponents: [{
                    Switch: {
                        checkboxId: "mouseOperationSwitch",
                        checked: false,
                        label: {
                            inner: {
                                dataOn: "ON",
                                dataOff: "OFF",
                            },
                        }
                    }
                }]
            }
        }
    ]
}

var SystemShow = {
    title: "显示",
    id: "SView-settingSystemShow",
    subComponents: [
        {
            CollapseItem: {
                label: "显示PMI",
                subComponents: [{
                    Switch: {
                        checkboxId: "PMISystemSwitch",
                        checked: true,
                        label: {
                            inner: {
                                dataOn: "ON",
                                dataOff: "OFF",
                            },
                        }
                    }
                }]
            }
        },
        {
            CollapseItem: {
                label: "显示子件视图",
                subComponents: [{
                    Switch: {
                        checkboxId: "childViewSystemSwitch",
                        checked: true,
                        label: {
                            inner: {
                                dataOn: "ON",
                                dataOff: "OFF",
                            },
                        }
                    }
                }]
            }
        },
        {
            CollapseItem: {
                label: "显示热点",
                subComponents: [{
                    Switch: {
                        checkboxId: "hotSelectSwitch",
                        checked:true,
                        label: {
                            inner: {
                                dataOn: "ON",
                                dataOff: "OFF",
                            },
                        }
                    }
                }]
            }
        },
        {
            CollapseItem: {
                id: "",
                label: "默认向上方向",
                subComponents: [
                    {
                        Select: {
                            id: "upSelect",
                            //onClick: "observeMode()",
                            options: [
                                {
                                    Option: {
                                        value: 0,
                                        content: "+x",
                                        selected: "selected"
                                    }
                                },
                                {
                                    Option: {
                                        value: 1,
                                        content: "-x",
                                    }
                                },
                                {
                                    Option: {
                                        value: 2,
                                        content: "+y",
                                    }
                                },
                                {
                                    Option: {
                                        value: 3,
                                        content: "-y",
                                    }
                                },
                                {
                                    Option: {
                                        value: 4,
                                        content: "+z",
                                    }
                                },
                                {
                                    Option: {
                                        value: 5,
                                        content: "-z",
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        },
        {
            CollapseItem: {
                id: "",
                label: "默认观察模式",
                subComponents: [
                    {
                        Select: {
                            id: "observeSelect",
                            onClick: "observeMode()",
                            options: [
                                {
                                    Option: {
                                        value: 0,
                                        content: "自由观察",
                                        selected: "selected"
                                    }
                                },
                                {
                                    Option: {
                                        value: 1,
                                        content: "动态观察",
                                    }
                                },
                                {
                                    Option: {
                                        value: 2,
                                        content: "约束观察",
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        },
        {
            CollapseItem: {
                label: "显示旋转中心",
                subComponents: [{
                    Switch: {
                        checkboxId: "showRotatingSystemSwitch",
                        checked: true,
                        label: {
                            inner: {
                                dataOn: "ON",
                                dataOff: "OFF",
                            },
                        }
                    }
                }]
            }
        },
        {
            CollapseItem: {
                label: "显示网格",
                subComponents: [{
                    Switch: {
                        checkboxId: "showGridSystemSwitch",
                        checked: false,
                        label: {
                            inner: {
                                dataOn: "ON",
                                dataOff: "OFF",
                            },
                        }
                    }
                }]
            }
        },
        {
            CollapseItem: {
                id: "",
                label: "默认显示场景",
                subComponents: [
                    {
                        Select: {
                            onClick: "observeMode()",
                            options: [
                                {
                                    Option: {
                                        value: 0,
                                        content: "默认视图",
                                        selected: "selected"
                                    }
                                },
                                {
                                    Option: {
                                        value: 1,
                                        content: "轴侧视图",
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        },
        {
            CollapseItem: {
                label: "显示FPS",
                subComponents: [{
                    Switch: {
                        checkboxId: "FPSSystemSwitch",
                        checked: "checked",
                        label: {
                            inner: {
                                dataOn: "ON",
                                dataOff: "OFF",
                            },
                        }
                    }
                }]
            }
        },
        {
            CollapseItem: {
                label: "显示坐标轴",
                subComponents: [{
                    Switch: {
                        checkboxId: "coordinateSystemSwitch",
                        checked: true,
                        label: {
                            inner: {
                                dataOn: "ON",
                                dataOff: "OFF",
                            },
                        }
                    }
                }]
            }
        },
        {
            CollapseItem: {
                label: "与模型同步显隐(批注、看板等)",
                subComponents: [{
                    Switch: {
                        checkboxId: "synchronousSystemSwitch",
                        checked: false,
                        label: {
                            inner: {
                                dataOn: "ON",
                                dataOff: "OFF",
                            },
                        }
                    }
                }]
            }
        },
        {
            CollapseItem: {
                label: "与模型同步高亮(批注、看板等)",
                subComponents: [{
                    Switch: {
                        checkboxId: "highlightedSystemSwitch",
                        checked: false,
                        label: {
                            inner: {
                                dataOn: "ON",
                                dataOff: "OFF",
                            },
                        }
                    }
                }]
            }
        },
        {
            CollapseItem: {
                label: "环境光遮蔽",
                subComponents: [{
                    Switch: {
                        checkboxId: "shelterSystemSwitch",
                        checked: true,
                        label: {
                            inner: {
                                dataOn: "ON",
                                dataOff: "OFF",
                            },
                        }
                    }
                }]
            }
        },
        {
            CollapseItem: {
                label: "显示阴影",
                subComponents: [{
                    Switch: {
                        checkboxId: "shadowSystemSwitch",
                        checked: false,
                        label: {
                            inner: {
                                dataOn: "ON",
                                dataOff: "OFF",
                            },
                        }
                    }
                }]
            }
        },
    ]
}
var SystemPerformance = {
    title: "性能",
    id: "SView-settingSystemPerformance",
    subComponents: [
        {
            CollapseItem: {
                label: "小件剔除模式",
                subComponents: [{
                    Select: {
                        id: "eliminateSelect",
                        options: [
                            {
                                Option: {
                                    value: 0,
                                    content: "屏幕",
                                    selected: "selected"
                                }
                            },
                            {
                                Option: {
                                    value: 1,
                                    content: "横屏",
                                }
                            },
                        ]
                    }
                }]
            }
        },
        {
            CollapseItem: {
                id: "",
                label: "小件剔除百分比",
                subComponents: [
                    {
                        Select: {
                            id: "eliminateNumSelect",
                            options: [
                                {
                                    Option: {
                                        value: 0,
                                        content: "0",
                                    }
                                },
                                {
                                    Option: {
                                        value: 1,
                                        content: "2",
                                    }
                                },
                                {
                                    Option: {
                                        value: 2,
                                        content: "4",
                                    }
                                },
                                {
                                    Option: {
                                        value: 3,
                                        content: "6",
                                    }
                                },
                                {
                                    Option: {
                                        value: 4,
                                        content: "8",
                                    }
                                },
                                {
                                    Option: {
                                        value: 5,
                                        content: "10",
                                    }
                                },
                                {
                                    Option: {
                                        value: 6,
                                        content: "12",
                                    }
                                },
                                {
                                    Option: {
                                        value: 7,
                                        content: "14",
                                    }
                                },
                                {
                                    Option: {
                                        value: 8,
                                        content: "16",
                                    }
                                },
                                {
                                    Option: {
                                        value: 9,
                                        content: "18",
                                    }
                                },
                                {
                                    Option: {
                                        value: 10,
                                        content: "20",
                                    }
                                },
                                {
                                    Option: {
                                        value: 11,
                                        content: "30",
                                    }
                                },
                                {
                                    Option: {
                                        value: 12,
                                        content: "40",
                                    }
                                },
                                {
                                    Option: {
                                        value: 13,
                                        content: "50",
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        },
        {
            CollapseItem: {
                label: "使用LOD",
                subComponents: [{
                    Switch: {
                        checkboxId: "LODSystemSwitch",
                        checked: true,
                        label: {
                            inner: {
                                dataOn: "ON",
                                dataOff: "OFF",
                            },
                        }
                    }
                }]
            }
        },
        {
            CollapseItem: {
                id: "",
                label: "LOD选择方式",
                subComponents: [
                    {
                        Select: {
                            id: "LODSelect",
                            options: [
                                {
                                    Option: {
                                        value: 0,
                                        content: "自动计算",
                                    }
                                },
                                {
                                    Option: {
                                        value: 1,
                                        content: "固定级别",
                                    }
                                },
                                {
                                    Option: {
                                        value: 2,
                                        content: "不高于级别",
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        },
        {
            CollapseItem: {
                id: "",
                label: "LOD级别",
                subComponents: [
                    {
                        Select: {
                            id: "LODLevelSelect",
                            options: [
                                {
                                    Option: {
                                        value: 0,
                                        content: "LOD0",
                                    }
                                },
                                {
                                    Option: {
                                        value: 1,
                                        content: "LOD1",
                                    }
                                },
                                {
                                    Option: {
                                        value: 2,
                                        content: "LOD2",
                                    }
                                },
                                {
                                    Option: {
                                        value: 3,
                                        content: "LOD3",
                                    }
                                },
                                {
                                    Option: {
                                        value: 4,
                                        content: "LOD4",
                                    }
                                },
                                {
                                    Option: {
                                        value: 5,
                                        content: "LOD5",
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        },
        {
            CollapseItem: {
                label: "调试",
                subComponents: [{
                    Switch: {
                        checkboxId: "debugSystemSwitch",
                        checked: false,
                        label: {
                            inner: {
                                dataOn: "ON",
                                dataOff: "OFF",
                            },
                        }
                    }
                }]
            }
        },
    ]
}
var SystemCommon = {
    title: "通用",
    id: "SView-settingSystem",
    subComponents: [
        {
            CollapseItem: {
                label: "持续旋转",
                subComponents: [{
                    Switch: {
                        checkboxId: "rotateSystemSwitch",
                        checked: false,
                        label: {
                            inner: {
                                dataOn: "ON",
                                dataOff: "OFF",
                            },
                        }
                    }
                }]
            }
        },
        {
            CollapseItem: {
                label: "显示包围盒尺寸",
                subComponents: [{
                    Switch: {
                        checkboxId: "boxSystemSwitch",
                        checked: false,
                        label: {
                            inner: {
                                dataOn: "ON",
                                dataOff: "OFF",
                            },
                        }
                    }
                }]
            }
        },
        {
            CollapseItem: {
                label: "多选",
                subComponents: [{
                    Switch: {
                        checkboxId: "multiSelectSwitch",
                        checked: false,
                        label: {
                            inner: {
                                dataOn: "ON",
                                dataOff: "OFF",
                            },
                        }
                    }
                }]
            }
        },
        {
            CollapseItem: {
                id: "setBackgroundSystem",
                label: "背景",
                subComponents: [
                    {
                        Button: {
                            id: "bgSelectSystem",
                            imgsrc: "images/background/white.png",
                            onClick: "showPopoverSelect('bgSystemPopoverSelect')",
                            subComponents: [
                                {
                                    PopoverSelect: {
                                        id: "bgSystemPopoverSelect",
                                        isShow: false,
                                        classes: [
                                            "SView-popoverSelect",
                                            "SView-popoverSelect-down",
                                            "SView-popoverSelect-tripleWidth",
                                            "SView-popoverSelect-background"
                                        ],
                                        subComponents: [
                                            {
                                                Button: {
                                                    id: "background_1",
                                                    imgsrc: "images/background/white.png",
                                                    onClick: "popoverSelectImg('bgSelect', 'background_1')"
                                                },
                                            },
                                            {
                                                Button: {
                                                    id: "background_2",
                                                    imgsrc: "images/background/black.png",
                                                    onClick: "popoverSelectImg('bgSelect', 'background_2')"
                                                },
                                            },
                                            {
                                                Button: {
                                                    id: "background_3",
                                                    imgsrc: "images/background/179.179.192.png",
                                                    onClick: "popoverSelectImg('bgSelect', 'background_3')"
                                                },
                                            },
                                            {
                                                Button: {
                                                    id: "background_4",
                                                    imgsrc: "images/background/234.234.234.png",
                                                    onClick: "popoverSelectImg('bgSelect', 'background_4')"
                                                },
                                            },
                                            {
                                                Button: {
                                                    id: "background_5",
                                                    imgsrc: "images/background/236-248-255.png",
                                                    onClick: "popoverSelectImg('bgSelect', 'background_5')"
                                                },
                                            },
                                            {
                                                Button: {
                                                    id: "background_6",
                                                    imgsrc: "images/background/148.202.239-255.255.255.png",
                                                    onClick: "popoverSelectImg('bgSelect', 'background_6')"
                                                },
                                            },
                                            {
                                                Button: {
                                                    id: "background_7",
                                                    imgsrc: "images/background/128.128.128-240.240.240.png",
                                                    onClick: "popoverSelectImg('bgSelect', 'background_7')"
                                                },
                                            },
                                            {
                                                Button: {
                                                    id: "background_8",
                                                    imgsrc: "images/background/230.230.230-170.170.170.png",
                                                    onClick: "popoverSelectImg('bgSelect', 'background_8')"
                                                },
                                            },
                                            {
                                                Button: {
                                                    id: "background_9",
                                                    imgsrc: "images/background/defaultcolor.png",
                                                    onClick: "popoverSelectImg('bgSelect', 'background_9')"
                                                },
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ],
            }
        },
        {
            CollapseItem: {
                label: "使用模型自带背景",
                subComponents: [{
                    Switch: {
                        checkboxId: "bgSystemSwitch",
                        checked: true,
                        label: {
                            inner: {
                                dataOn: "ON",
                                dataOff: "OFF",
                            },
                        }
                    }
                }]
            }
        },
        {
            CollapseItem: {
                label: "反转鼠标滚动方向",
                subComponents: [{
                    Switch: {
                        checkboxId: "reverseSystemSwitch",
                        checked: false,
                        label: {
                            inner: {
                                dataOn: "ON",
                                dataOff: "OFF",
                            },
                        }
                    }
                }]
            }
        },
        {
            CollapseItem: {
                label: "打开时仅加载装配结构",
                subComponents: [{
                    Switch: {
                        checkboxId: "loadingSystemSwitch",
                        checked: false,
                        label: {
                            inner: {
                                dataOn: "ON",
                                dataOff: "OFF",
                            },
                        }
                    }
                }]
            }
        },
        {
            CollapseItem: {
                id: "",
                label: "语言",
                subComponents: [
                    {
                        Select: {
                            id: "languageSelect",
                            options: [
                                {
                                    Option: {
                                        value: 1,
                                        content: "简体中文",
                                    }
                                },
                                {
                                    Option: {
                                        value: 2,
                                        content: "English",
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
}
var SettingDialog = {
    Dialog: {
        classes: [
            "SView-dialog",
            "SView-settingMenu-dialog"
        ],
        showBack:true,
        id: "settingMenuDialog",
        closeBtnOnClick: "closeDialog('settingMenuDialog')",
        title: "设置",
        contentClasses: [
            "SView-settingMenu-dialog-content",
            "SView-dialog-content",
        ],
        subComponents: [
            {
                Tabs: {
                    id: "settingMenuTabs",
                    tabContent: [
                        {
                            dataActive: "true",
                            title: "文档",
                            dataClass: "SView-settingDocument",
                            subComponentsId: "SView-settingDocument",
                            onClick: "changeTabs('settingMenuTabs', 'SView-settingDocument')",
                            subComponents: [
                                {
                                    Collapse: DocumentCommon,
                                },
                                {
                                    Collapse: DocumentWalking,
                                }
                            ]
                        },
                        {
                            title: "系统",
                            dataClass: "SView-settingSystem",
                            onClick: "changeTabs('settingMenuTabs', 'SView-settingSystem')",
                            subComponentsId: "SView-settingSystem",
                            subComponents: [
                                {
                                    Collapse: SystemCommon,
                                },
                                {
                                    Collapse: SystemShow,
                                },
                                {
                                    Collapse: SystemPerformance,
                                }

                            ]
                        }
                    ]
                }
            }
        ],
        buttons: [{
            Button: {
                type: "basicButton",
                classes: [
                    "SView-button",
                    "SView-button-primary"
                ],
                id: "confirmSetting",
                content: "确定",
            }
        }]
    }
}
