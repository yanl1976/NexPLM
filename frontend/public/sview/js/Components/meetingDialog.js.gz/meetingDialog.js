var MeetingDialog = {
    "MeetingDialog": {
        "id": "meetingDialog",
        "classes": [
            "SView-meeting"
        ],
        "titleBtns": [
            {
                "Button": {
                    "classes": [
                        "SView-button-iconBtn",
                        "meetingSet"
                    ],
                    "onClick": "showMeetingDialog('meetingDialog',SettingMeetingDialog)",
                    "imgsrc": "images/meeting/MeetingSet.png"
                }
            },
            {
                "Button": {
                    "classes": [
                        "SView-button-iconBtn",
                        "meetingExist",
                    ],
                    "onClick": "closeDialog('meetingDialog', 'meetingMainMenu')",
                    "imgsrc": "images/meeting/MeetingExist.png"
                }
            }
        ],
        "images": [
            {
                "classes": [
                    "SView-meeting-create"
                ],
                "imgsrc": "images/meeting/meeting_create.png",
                "onClick": "showMeetingDialog('meetingDialog',CreateMeetingDialog)"
            }, 
            {
                "classes": [
                    "SView-meeting-join"
                ],
                "imgsrc": "images/meeting/meeting_join.png",
                "onClick": "showMeetingDialog('meetingDialog',JoinMeetingDialog)"
            },
            {
                "classes": [
                    "SView-meeting-record"
                ],
                "imgsrc": "images/meeting/meeting_minutes.png",
                // "onClick": "showMeetingRecord()"
            }
        ]
    }
}
//创建会议
var CreateMeetingDialog = {
    "Dialog": {
        "id": "create_meeting_dialog",
        "closeBtnOnClick": "closeDialog('create_meeting_dialog')",
        "title": "创建会议",
        "subComponents": [
            {
                Form: {
                    id: "creatMeetingForm",
                    classes: [
                        "SView-form",
                        "SView-form-middle"
                    ],
                    subComponents: [
                        {
                            WithBothInput: {
                                id: "creatMeeting",
                                warning: "主题不能为空！",
                                title:"主题",
                                subComponents: [
                                    {
                                        Input: {
                                            id: "creatMeetingInput",
                                            value: "主题",
                                            placeHolder: "请输入主题",
                                            onInput: "checkLength('creatMeetingInput')"
                                        }
                                    }
                                ]
                            }
                        },
                        {
                            WithBothInput: {
                                id: "creatMeeting",
                                title: "昵称",
                                warning: "昵称不能为空！",
                                subComponents: [
                                    {
                                        Input: {
                                            id: "creatMeetingNickName",
                                            value: "昵称",
                                            placeHolder: "请输入昵称",
                                            onInput: "checkLength('creatMeetingNickName')"
                                        }
                                    }
                                ]
                            }
                        }
                    ]
                }
            },
        ],
        "buttons": [{
            Button: {
                "type": "basicButton",
                "classes": [
                    "SView-button",
                    "SView-button-primary"
                ],
                "id": "confirmExit",
                "content": "确定",
                "onClick": ""
            }

        }]
    }
}
//加入会议
var JoinMeetingDialog = {
    "Dialog": {
        "id": "join_meeting_dialog",
        "hideTitle":true,
        "subComponents": [
            {
                Tabs: {
                    id: "join_meeting_tabs",
                    tabContent: [
                        {
                            dataActive: "true", // 当前选中标签页
                            title: "会议列表",
                            dataClass: "tabTest_1",
                            subComponentsId: "tabTest_1", // 与dataClass保持一致，控制标签页内容显隐
                            subComponents: [
                                {
                                    Table: {
                                        id: "tableTest",
                                        classes: [
                                            "SView-table", // 若不写，默认类名为"SView-table"
                                        ],
                                        cellTitle: ["主题", "会议号", "主持人","创建时间"], // 表格标题
                                        cellContent: [
                                            ["LYA-AL00 的会议", "65558424", "LYA-AL00","2022-03-23 15:48:56"],
                                            ["Administrator的会议", "34739797", "DE", "2021-08-02 16:24:05"],
                                        ] // 表格内容
                                    }
                                }
                            ]
                        },
                        {
                            title: "会议号",
                            dataClass: "tabTest_2",
                            subComponentsId: "tabTest_2",
                            subComponents: [{
                                Form: {
                                    id: "creatMeetingForm",
                                    classes: [
                                        "SView-form",
                                        "SView-form-middle"
                                    ],
                                    subComponents: [
                                        {
                                            WithBothInput: {
                                                id: "creatMeeting",
                                                warning: "会议号不能为空！",
                                                title: "会议号",
                                                subComponents: [
                                                    {
                                                        Input: {
                                                            id: "creatMeetingInput",
                                                            value: "会议号",
                                                            placeHolder: "请输入会议号",
                                                            onInput: "checkLength('creatMeetingInput')"
                                                        }
                                                    }
                                                ]
                                            }
                                        },
                                        {
                                            WithBothInput: {
                                                id: "creatMeeting",
                                                title: "昵称",
                                                warning: "昵称不能为空！",
                                                subComponents: [
                                                    {
                                                        Input: {
                                                            id: "creatMeetingNickName",
                                                            value: "昵称",
                                                            placeHolder: "请输入昵称",
                                                            onInput: "checkLength('creatMeetingNickName')"
                                                        }
                                                    }
                                                ]
                                            }
                                        }
                                    ]
                                }
                            }]
                        }
                    ] // 标签页内容
                } 
            },
        ],
        "buttons": [{
            Button: {
                "type": "basicButton",
                "classes": [
                    "SView-button",
                    "SView-button-primary"
                ],
                "id": "confirmExit",
                "content": "加入会议",
                "onClick": ""
            }
        }, {
                Button: {
                    "type": "basicButton",
                    "classes": [
                        "SView-button",
                        "SView-button-default"
                    ],
                    "id": "confirmExit",
                    "content": "取消",
                    "onClick": "closeDialog('join_meeting_dialog')",
                }
            }]
    }
}
//会议设置
var SettingMeetingDialog = {
    "Dialog": {
        "id": "setting_meeting_dialog",
        "closeBtnOnClick": "closeDialog('setting_meeting_dialog')",
        "title": "会议设置",
        "subComponents": [
            {
                Form: {
                    id: "setMeetingForm",
                    classes: [
                        "SView-form",
                        "SView-form-middle"
                    ],
                    subComponents: [
                        {
                            WithBothInput: {
                                id: "setMeeting",
                                title: "昵称",
                                warning: "昵称不能为空！",
                                subComponents: [
                                    {
                                        Input: {
                                            id: "setMeetingNickName",
                                            value: "昵称",
                                            placeHolder: "请输入昵称",
                                            onInput: "checkLength('setMeetingNickName')"
                                        }
                                    }
                                ]
                            }
                        }
                    ]
                }
            },
        ],
        "buttons": [{
            Button: {
                "type": "basicButton",
                "classes": [
                    "SView-button",
                    "SView-button-primary"
                ],
                "id": "confirmExit",
                "content": "确定",
                "onClick": ""
            }

        },{
                Button: {
                    "type": "basicButton",
                    "classes": [
                        "SView-button",
                        "SView-button-primary"
                    ],
                    "id": "confirmExit",
                    "content": "重置",
                    "onClick": ""
                }

            }]
    }
}