var AssemblyDialog = {
    TreeDialog: {
        classes: [
            "SView-treeDialog"
        ],
        id: "assemblyTreeDialog",
        title: {
            classes: [
                "SView-treeDialog-title"
            ],
            id: "treeDialogTabs",
            closeBtnOnClick: "closeDialog('assemblyTreeDialog', 'assemblyTree')",
            tabContent: [
                {
                    Button: {
                        dataClass: "SView-assemblyTree",
                        id: "assemblyTreeBtn",
                        imgsrc: "images/rightMenuBtn/sview_assembly.png",
                        title: "装配",
                        onClick: "changeTreeTabs('treeDialogTabs','SView-assemblyTree')",
                        highLight: true
                    }
                },
                {
                    Button: {
                        dataClass: "SView-viewList",
                        id: "viewListBtn",
                        imgsrc: "images/rightMenuBtn/button_view.png",
                        title: "视图",
                        onClick: "changeTreeTabs('treeDialogTabs', 'SView-viewList')",
                    }
                }
            ],
        },
        search: {
            subComponents: [
                {
                    WithBtnInput: {
                        id: "searchInput",
                        classes: [
                            "SView-input-withBtn"
                        ],
                        subComponents: [
                            {
                                Input: {
                                    id: "searchContentInput",
                                    classes: [
                                        "SView-complexInput"
                                    ],
                                    value: "",
                                    placeHolder: "请输入搜索内容",
                                    autoComplete: "off"
                                },
                            },
                            {
                                InputButton: {
                                    id: "searchBtn",
                                    onClick: "checkLength('searchContentInput','assemblyTreeDialog')",
                                    imgsrc: "images/search_white.png",
                                    btnTitle: "",
                                    warning: "搜索内容不能为空！"
                                }
                            }
                        ]
                    }
                }
            ]
        },
        content_1: {
            id: "SView-assemblyTree",
            dataActive: "true",
            subComponents: [
                {
                    Tree: {
                        "id": "SView-tree",
                        "classes": [
                            "SView-tree",
                            "SView-tree-content"
                        ],
                        data: [
                            {
                                name: "减速器装配",
                                active: false,
                                checked: true,
                                id: "1",
                                img: "",
                                children: [
                                    // 模拟数据
                                    {
                                        name: "Asm齿轮轴",
                                        active: false,
                                        checked: true,
                                        id: "2",
                                        img: "",
                                        children: [
                                            {
                                                name: "齿轮轴",
                                                active: false,
                                                checked: true,
                                                id: 3,
                                                img: "",
                                                children: []
                                            },
                                            {
                                                id: 4,
                                                name: "80轴承",
                                                children: [],
                                                active: false,
                                                checked: true,
                                                img: ""
                                            }
                                        ]
                                    },
                                    {
                                        name: "主轴装配",
                                        active: false,
                                        checked: true,
                                        id: 21,
                                        img: "",
                                        children: [
                                            {
                                                name: "100轴承",
                                                children: [],
                                                active: false,
                                                checked: true,
                                                id: 20,
                                                img: ""
                                            },
                                            {
                                                id: 19,
                                                name: "主轴",
                                                children: [],
                                                active: false,
                                                checked: true,
                                                img: ""
                                            }
                                        ]
                                    },
                                    {
                                        name: "视孔盖",
                                        active: false,
                                        checked: true,
                                        id: 22,
                                        img: "",
                                        children: []
                                    }
                                ]
                            }
                        ],
                        treeRightClickMenu: {
                            RightClickMenu: {
                                id: "treeRightClickMenu",
                                classes: [
                                    "SView-rightClickMenu",
                                    "SView-tree-rightClickMenu"
                                ],
                                subComponents: [
                                    {
                                        RightClickBtn: {
                                            "id": "treeAdd",
                                            "content": "添加",
                                            "onClick": "addAsemble()"
                                        }
                                    },
                                    {
                                        RightClickBtn: {
                                            "id": "treeLoad",
                                            "content": "加载",
                                            "onClick": "loadOrUnload('install')"
                                        }
                                    },
                                    {
                                        RightClickBtn: {
                                            "id": "treeUninstall",
                                            "content": "卸载",
                                            "onClick": "loadOrUnload('uninstall')"
                                        }
                                    },
                                    {
                                        RightClickBtn: {
                                            "id": "treeRemove",
                                            "content": "删除",
                                            "onClick":"confirmRemoveAsemble()"
                                        }
                                    },
                                    {
                                        RightClickBtn: {
                                            "id": "treeCopy",
                                            "content": "复制",
                                            "onClick":"copyAsemble()"
                                        }
                                    },
                                    {
                                        RightClickBtn: {
                                            "id": "treeShear",
                                            "content": "剪切",
                                            "onClick": "cutAsemble()"
                                        }
                                    },
                                    {
                                        RightClickBtn: {
                                            "id": "treePaste",
                                            "content": "粘贴",
                                            "onClick": "pasteAsemble()"
                                        }
                                    },
                                    {
                                        RightClickBtn: {
                                            "id": "treeRename",
                                            "content": "重命名",
                                            "onClick": "nodeRename()"
                                        }
                                    }
                                ]
                            }
                        }
                    }
                }
            ]
        },
        content_2: {
            id: "SView-viewList",
            dataActive: "false",
            subComponents: [
                {
                    Button: {
                        type: "iconTextButton_left",
                        classes: [
                            "SView-button-iconText",
                            "SView-button-iconLR",
                            "SView-button-primary",
                            "createNewViewBtn"
                        ],
                        id: "createNewView",
                        content: "新建视图",
                        imgsrc: "images/button_snapshot_.png",
                        onClick: "createView()"
                    }
                },
                {
                    ViewList: {
                        id: "sview_view_panel",
                        classes: [
                            "SView-pull-left-div",
                        ],
                        data: [
                            {
                                id: 111,
                                name: "视图1",
                                time: "2022-03-03 16:09:41",
                                author: "游客",
                                imgSrc: "https://service.sv3d.cn/data/upload/modelfile/20210205/4b9861c4-2e4b-4abe-b5cf-11b82bf744f5/13ee6732-534c-4336-82ab-a88e47fe6629_1.png"
                            },
                            {
                                id: 222,
                                name: "俯视图"
                            }
                        ]
                    }
                }
            ]
        }
    }
}
var CreateView = {
    "Dialog": {
        "id": "create_view_dialog",
        "closeBtnOnClick": "closeDialog('create_view_dialog')",
        "title": "视图名称",
        showBack: true,
        "subComponents": [
            {
                Form: {
                    id: "createViewForm",
                    classes: [
                        "SView-form",
                        "SView-form-middle"
                    ],
                    subComponents: [
                        {
                            WithBothInput: {
                                id: "createView",
                                title: "视图名称",
                                warning: "视图名称不能为空！",
                                subComponents: [
                                    {
                                        Input: {
                                            id: "createViewName",
                                            value: "视图1124",
                                            placeHolder: "请输入视图名称",
                                            onInput: "checkLength('createViewName')"
                                        }
                                    }
                                ]
                            }
                        }
                    ]
                }
            },
        ],
        "buttons": [{
            Button: {
                "type": "basicButton",
                "classes": [
                    "SView-button",
                    "SView-button-primary"
                ],
                "id": "confirmExit",
                "content": "确定",
                "onClick": ""
            }

        }, {
            Button: {
                "type": "basicButton",
                "classes": [
                    "SView-button",
                    "SView-button-default"
                ],
                "id": "confirmExit",
                "content": "取消",
                "onClick": "closeDialog('create_view_dialog')",
            }

        }]
    }
}