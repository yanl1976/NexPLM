// ---------- 底部主菜单 -----------
var MainBottomMenu = {
    "BottomMenu": {
        "id": "mainBottomMenu",
        "classes": [
            "SView-bottomMenu",
        ],
        "subComponents": [
            {
                "Button": {
                    "id": "move",
                    "imgsrc": "images/moreMenu/sview_movecontrol_translation.png",
                    "title": "移动",
                    "onClick": "enterBottomMenu(MoveMenu)"
                }
            },
            {
                "Button": {
                    "id": "annotate",
                    "imgsrc": "images/moreMenu/button_note.png",
                    "title": "批注",
                    "onClick": "enterBottomMenu(AnnotateMenu)"
                }
            },
            {
                "Button": {
                    "id": "animation",
                    "imgsrc": "images/moreMenu/button_ani_play.png",
                    "title": "动画",
                    "onClick": "enterBottomMenu(AnimationMenu)",
                }
            },
            {
                "Button": {
                    "id": "measure",
                    "imgsrc": "images/moreMenu/button_measure.png",
                    "title": "测量",
                    "onClick": "enterBottomMenu(MeasureMenu)",
                }

            },
            {
                "Button": {
                    "id": "section",
                    "imgsrc": "images/moreMenu/button_section.png",
                    "title": "剖切",
                    "onClick": "enterBottomMenu(SectioneMenu)",
                }
            },
            {
                "Button": {
                    "id": "explosive",
                    "imgsrc": "images/moreMenu/button_explosive.png",
                    "title": "爆炸",
                    "onClick": "enterBottomMenu(ExplosiveMenu)",
                }
            },
            {
                "Button": {
                    "id": "snapshot",
                    "imgsrc": "images/moreMenu/button_snapshot.png",
                    "title": "快照",
                    "onClick": "snapShot()",
                }
            },
            {
                "Button": {
                    "id": "clear",
                    "imgsrc": "images/moreMenu/sview_clear.png",
                    "title": "清空",
                    "onClick": "showPopoverSelect('clearAllMode')",
                    "subComponents": [{
                        "PopoverSelect": {
                            "id": "clearAllMode",
                            "isShow": false,
                            "subComponents": [
                                {
                                    "Button": {
                                        "id": "clearAnnotates",
                                        "imgsrc": "images/moreMenu/button_note.png",
                                        "title": "清空批注对象",
                                        "onClick": "confirmDelete('clearAnnotates')"
                                    }
                                },
                                {
                                    "Button": {
                                        "id": "clearMeasurements",
                                        "imgsrc": "images/moreMenu/button_measure.png",
                                        "title": "清空测量对象",
                                        "onClick": "confirmDelete('clearMeasurements')"
                                    }
                                },
                                {
                                    "Button": {
                                        "id": "clearSectionPlanes",
                                        "imgsrc": "images/moreMenu/button_section.png",
                                        "title": "清空剖切面",
                                        "onClick": "confirmDelete('clearSectionPlanes')",
                                    }
                                },
                            ]
                        }
                    }
                    ]
                }
            }
        ]
    }
}

// ---------- 批注主菜单 -----------
var AnnotateMenu = {
    "BottomMenu": {
        "id": "annotate_menu",
        "classes": [
            "SView-bottomMenu",
        ],
        "subComponents": [
            {
                "Button": {
                    "id": "gesture",
                    "imgsrc": "images/moreMenu/annotate/sview_gesturenote.png",
                    "title": "手势批注",
                    "onClick": "enterBottomMenu(GestureMenu, AnnotateMenu)"
                }
            },
            {
                "Button": {
                    "id": "textnote",
                    "imgsrc": "images/moreMenu/annotate/sview_textnote.png",
                    "title": "文本批注",
                    "onClick": "commandClickFun('textnote','AnnotationTextCommand')"
                }
            },
            {
                "Button": {
                    "id": "sequence",
                    "imgsrc": "images/moreMenu/annotate/button_sequence.png",
                    "title": "序号",
                    "onClick": "commandClickFun('sequence','AnnotationNumberCommand')",
                }
            },
            {
                "Button": {
                    "id": "component",
                    "imgsrc": "images/moreMenu/annotate/button_component.png",
                    "title": "模型名称",
                    "onClick": "commandClickFun('distanceMeasure','AnnotationComponentCommand')",
                }
            },
            {
                "Button": {
                    "id": "section",
                    "imgsrc": "images/moreMenu/annotate/sview_note_edit.png",
                    "title": "编辑",
                    "onClick": "commandClickFun('section','AnnotationEditCommand')",
                }
            },
            {
                "Button": {
                    "id": "deleteAnnotate",
                    "imgsrc": "images/moreMenu/annotate/sview_clear.png",
                    "title": "删除",
                    // "onClick": "enterBottomMenu('explosiveMenu')",
                    "onClick": "confirmDelete('deleteAnnotate')",
                }
            },
            {
                "Button": {
                    "id": "exitAnnotate",
                    "imgsrc": "images/moreMenu/translation/sview_button_exit.png",
                    "title": "退出",
                    // "onClick": "exitBottomMenu(AnnotateMenu)",
                    "onClick": "confirmExit('AnnotateMenu')",
                }
            },
        ]
    }
}
// ----------距离测量菜单 -----------
var MeasureMenu = {
    "BottomMenu": {
        "id": "measure_distance_menu",
        "classes": [
            "SView-bottomMenu",
        ],
        "subComponents": [
            {
                "Button": {
                    "id": "measure_distance_select",
                    "imgsrc": "images/moreMenu/measure/sview_measure_distance.png",
                    "title": "距离测量",
                    "onClick": "showPopoverSelect('measure_select')",
                    "subComponents": [{
                        "PopoverSelect": {
                            "id": "measure_select",
                            "isShow":false,
                            "subComponents": [
                                {
                                    "Button": {
                                        "id": "measure_distance",
                                        "imgsrc": "images/moreMenu/measure/sview_measure_distance.png",
                                        "highLight": true,
                                        "title": "距离测量",
                                        "onClick": "hidePopoverSelect('measure_select')"
                                    }
                                },
                                {
                                    "Button": {
                                        "id": "measure_angle",
                                        "imgsrc": "images/moreMenu/measure/sview_measure_angle.png",
                                        "title": "角度测量",
                                        "onClick": "enterBottomMenu(MeasureAngleMenu,MeasureMenu)"
                                    }
                                },
                                {
                                    "Button": {
                                        "id": "measure_diameter",
                                        "imgsrc": "images/moreMenu/measure/sview_measure_diameter.png",
                                        "title": "圆相关测量",
                                        "onClick": "enterBottomMenu(MeasureDiameterMenu,MeasureMenu)",
                                    }
                                },
                                {
                                    "Button": {
                                        "id": "measure_attributes",
                                        "imgsrc": "images/moreMenu/measure/sview_measure_attributes.png",
                                        "title": "属性测量",
                                        "onClick": "enterBottomMenu(MeasureAttributesMenu,MeasureMenu)",
                                    }
                                },
                            ]
                        }
                    }
                    ]
                }
            },
            {
                "Button": {
                    "id": "measure_dd",
                    "imgsrc": "images/moreMenu/measure/sview_measure_distance_dd.png",
                    "title": "点点测量",
                    "onClick": "commandClickFun('measure_dd','MeasureDistanceCommand','PToPDistance')"
                }
            },
            {
                "Button": {
                    "id": "measure_dl",
                    "imgsrc": "images/moreMenu/measure/sview_measure_distance_dl.png",
                    "title": "点线测量",
                    "onClick": "commandClickFun('measure_dl','MeasureDistanceCommand')",
                }
            },
            {
                "Button": {
                    "id": "measure_ps",
                    "imgsrc": "images/moreMenu/measure/sview_measure_distance_ps.png",
                    "title": "点面测量",
                    "onClick": "commandClickFun('measure_ps','MeasureDistanceCommand')",
                }
            },
            {
                "Button": {
                    "id": "measure_ll",
                    "imgsrc": "images/moreMenu/measure/sview_measure_distance_ll.png",
                    "title": "线线测量",
                    "onClick": "commandClickFun('measure_ll','MeasureDistanceCommand')",
                }
            },
            {
                "Button": {
                    "id": "measure_ls",
                    "imgsrc": "images/moreMenu/measure/sview_measure_distance_ls.png",
                    "title": "线面测量",
                    "onClick": "commandClickFun('measure_ls','MeasureDistanceCommand')",
                }
            },
            {
                "Button": {
                    "id": "measure_ss",
                    "imgsrc": "images/moreMenu/measure/sview_measure_distance_ss.png",
                    "title": "面面测量",
                    "onClick": "commandClickFun('measure_ss','MeasureDistanceCommand')",
                }
            },
            {
                "Button": {
                    "id": "measure_thickness",
                    "imgsrc": "images/moreMenu/measure/sview_measure_distance_thickness.png",
                    "title": "厚度",
                    "onClick": "commandClickFun('measure_thickness','MeasureDistanceCommand')",
                }
            },
            {
                "Button": {
                    "id": "deleteAnnotate",
                    "imgsrc": "images/moreMenu/annotate/sview_clear.png",
                    "title": "删除",
                    "onClick": "confirmDelete('deleteMeasure')",
                }
            },
            {
                "Button": {
                    "id": "exitAnnotate",
                    "imgsrc": "images/moreMenu/translation/sview_button_exit.png",
                    "title": "退出",
                    "onClick": "confirmExit('MeasureMenu')",
                }
            },
        ]
    }
}
// ----------角度测量菜单 -----------
var MeasureAngleMenu = {
    "BottomMenu": {
        "id": "measure_angle_menu",
        "classes": [
            "SView-bottomMenu",
        ],
        "subComponents": [
            {
                "Button": {
                    "id": "measure_angle_select",
                    "imgsrc": "images/moreMenu/measure/sview_measure_angle.png",
                    "title": "角度测量",
                    "onClick": "showPopoverSelect('angle_select')",
                    "subComponents": [{
                        "PopoverSelect": {
                            "id": "angle_select",
                            "isShow": false,
                            "subComponents": [
                                {
                                    "Button": {
                                        "id": "measure_distance",
                                        "imgsrc": "images/moreMenu/measure/sview_measure_distance.png",
                                        "title": "距离测量",
                                        "onClick": "enterBottomMenu(MeasureMenu,MeasureAngleMenu)"
                                    }
                                },
                                {
                                    "Button": {
                                        "id": "measure_angle",
                                        "imgsrc": "images/moreMenu/measure/sview_measure_angle.png",
                                        "title": "角度测量",
                                        "highLight": true,
                                        "onClick": "hidePopoverSelect('measure_select')"
                                    }
                                },
                                {
                                    "Button": {
                                        "id": "measure_diameter",
                                        "imgsrc": "images/moreMenu/measure/sview_measure_diameter.png",
                                        "title": "圆相关测量",
                                        "onClick": "enterBottomMenu(MeasureDiameterMenu,MeasureAngleMenu)",
                                    }
                                },
                                {
                                    "Button": {
                                        "id": "measure_attributes",
                                        "imgsrc": "images/moreMenu/measure/sview_measure_attributes.png",
                                        "title": "属性测量",
                                        "onClick": "enterBottomMenu(MeasureAttributesMenu,MeasureAngleMenu)",
                                    }
                                },
                            ]
                        }
                    }
                    ]
                }
            },
            {
                "Button": {
                    "id": "angle_ll",
                    "imgsrc": "images/moreMenu/measure/sview_measure_angle_ll.png",
                    "title": "线线角度",
                    "onClick": "commandClickFun('angle_ll','MeasureDistanceCommand','PToPDistance')"
                }
            },
            {
                "Button": {
                    "id": "angle_lf",
                    "imgsrc": "images/moreMenu/measure/sview_measure_angle_lf.png",
                    "title": "线面角度",
                    "onClick": "commandClickFun('angle_lf','MeasureDistanceCommand')",
                }
            },
            {
                "Button": {
                    "id": "angle_ff",
                    "imgsrc": "images/moreMenu/measure/sview_measure_angle_ff.png",
                    "title": "面面角度",
                    "onClick": "commandClickFun('angle_ff','MeasureDistanceCommand')",
                }
            },
            {
                "Button": {
                    "id": "deleteAnnotate",
                    "imgsrc": "images/moreMenu/annotate/sview_clear.png",
                    "title": "删除",
                    "onClick": "confirmDelete('deleteMeasure')",
                }
            },
            {
                "Button": {
                    "id": "exitAnnotate",
                    "imgsrc": "images/moreMenu/translation/sview_button_exit.png",
                    "title": "退出",
                    "onClick": "confirmExit('MeasureAngleMenu')",
                }
            },
        ]
    }
}
// ----------圆相关测量菜单 -----------
var MeasureDiameterMenu = {
    "BottomMenu": {
        "id": "measure_diameter_menu",
        "classes": [
            "SView-bottomMenu",
        ],
        "subComponents": [
            {
                "Button": {
                    "id": "measure_diameter_select",
                    "imgsrc": "images/moreMenu/measure/sview_measure_diameter.png",
                    "title": "圆相关测量",
                    "onClick": "showPopoverSelect('diameter_select')",
                    "subComponents": [{
                        "PopoverSelect": {
                            "id": "diameter_select",
                            "isShow": false,
                            "subComponents": [
                                {
                                    "Button": {
                                        "id": "measure_distance",
                                        "imgsrc": "images/moreMenu/measure/sview_measure_distance.png",
                                        "title": "距离测量",
                                        "onClick": "enterBottomMenu(MeasureMenu,MeasureDiameterMenu)"
                                    }
                                },
                                {
                                    "Button": {
                                        "id": "measure_angle",
                                        "imgsrc": "images/moreMenu/measure/sview_measure_angle.png",
                                        "title": "角度测量",
                                        "onClick": "enterBottomMenu(MeasureAngleMenu,MeasureDiameterMenu)"
                                    }
                                },
                                {
                                    "Button": {
                                        "id": "measure_diameter",
                                        "imgsrc": "images/moreMenu/measure/sview_measure_diameter.png",
                                        "title": "圆相关测量",
                                        "highLight": true,
                                        "onClick": "hidePopoverSelect('measure_select')",
                                    }
                                },
                                {
                                    "Button": {
                                        "id": "measure_attributes",
                                        "imgsrc": "images/moreMenu/measure/sview_measure_attributes.png",
                                        "title": "属性测量",
                                        "onClick": "enterBottomMenu(MeasureAttributesMenu,MeasureDiameterMenu)",
                                    }
                                },
                            ]
                        }
                    }
                    ]
                }
            },
            {
                "Button": {
                    "id": "circle_center",
                    "imgsrc": "images/moreMenu/measure/sview_measure_circle_center.png",
                    "title": "弧线创建圆心",
                    "onClick": "commandClickFun('circle_center','MeasureDistanceCommand','PToPDistance')"
                }
            },
            {
                "Button": {
                    "id": "point_center",
                    "imgsrc": "images/moreMenu/measure/sview_measure_point_center.png",
                    "title": "三点创建圆心",
                    "onClick": "commandClickFun('point_center','MeasureDistanceCommand')",
                }
            },
            {
                "Button": {
                    "id": "diameter",
                    "imgsrc": "images/moreMenu/measure/sview_measure_diameter.png",
                    "title": "直径",
                    "onClick": "commandClickFun('diameter','MeasureDistanceCommand')",
                }
            },
            {
                "Button": {
                    "id": "radius",
                    "imgsrc": "images/moreMenu/measure/sview_measure_radius.png",
                    "title": "半径",
                    "onClick": "commandClickFun('radius','MeasureDistanceCommand')",
                }
            },
            {
                "Button": {
                    "id": "shaft_shaft",
                    "imgsrc": "images/moreMenu/measure/sview_measure_shaft_shaft.png",
                    "title": "轴距",
                    "onClick": "commandClickFun('shaft_shaft','MeasureDistanceCommand')",
                }
            },
            {
                "Button": {
                    "id": "center_center",
                    "imgsrc": "images/moreMenu/measure/sview_measure_center_center.png",
                    "title": "圆心距",
                    "onClick": "commandClickFun('center_center','MeasureDistanceCommand')",
                }
            },
            {
                "Button": {
                    "id": "deleteAnnotate",
                    "imgsrc": "images/moreMenu/annotate/sview_clear.png",
                    "title": "删除",
                    "onClick": "confirmDelete('deleteMeasure')",
                }
            },
            {
                "Button": {
                    "id": "exitAnnotate",
                    "imgsrc": "images/moreMenu/translation/sview_button_exit.png",
                    "title": "退出",
                    "onClick": "confirmExit('MeasureDiameterMenu')",
                }
            },
        ]
    }
}
// ----------属性测量菜单 -----------
var MeasureAttributesMenu = {
    "BottomMenu": {
        "id": "measure_attributes_menu",
        "classes": [
            "SView-bottomMenu",
        ],
        "subComponents": [
            {
                "Button": {
                    "id": "measure_attributes_select",
                    "imgsrc": "images/moreMenu/measure/sview_measure_diameter.png",
                    "title": "属性测量",
                    "onClick": "showPopoverSelect('attributes_select')",
                    "subComponents": [{
                        "PopoverSelect": {
                            "id": "attributes_select",
                            "isShow": false,
                            "subComponents": [
                                {
                                    "Button": {
                                        "id": "measure_distance",
                                        "imgsrc": "images/moreMenu/measure/sview_measure_distance.png",
                                        "title": "距离测量",
                                        "onClick": "enterBottomMenu(MeasureMenu,MeasureAttributesMenu)"
                                    }
                                },
                                {
                                    "Button": {
                                        "id": "measure_angle",
                                        "imgsrc": "images/moreMenu/measure/sview_measure_angle.png",
                                        "title": "角度测量",
                                        "onClick": "enterBottomMenu(MeasureAngleMenu,MeasureAttributesMenu)"
                                    }
                                },
                                {
                                    "Button": {
                                        "id": "measure_diameter",
                                        "imgsrc": "images/moreMenu/measure/sview_measure_diameter.png",
                                        "title": "圆相关测量",
                                        "onClick": "enterBottomMenu(MeasureDiameterMenu,MeasureAttributesMenu)",
                                    }
                                },
                                {
                                    "Button": {
                                        "id": "measure_attributes",
                                        "imgsrc": "images/moreMenu/measure/sview_measure_attributes.png",
                                        "title": "属性测量",
                                        "highLight": true,
                                        "onClick": "hidePopoverSelect('measure_select')",
                                    }
                                },
                            ]
                        }
                    }
                    ]
                }
            },
            {
                "Button": {
                    "id": "porperty_dot",
                    "imgsrc": "images/moreMenu/measure/sview_measure_porperty_dot.png",
                    "title": "点",
                    "onClick": "commandClickFun('porperty_dot','MeasureDistanceCommand','PToPDistance')"
                }
            },
            {
                "Button": {
                    "id": "porperty_line",
                    "imgsrc": "images/moreMenu/measure/sview_measure_porperty_line.png",
                    "title": "线",
                    "onClick": "commandClickFun('porperty_line','MeasureDistanceCommand')",
                }
            },
            {
                "Button": {
                    "id": "porperty_surface",
                    "imgsrc": "images/moreMenu/measure/sview_measure_porperty_surface.png",
                    "title": "面",
                    "onClick": "commandClickFun('porperty_surface','MeasureDistanceCommand')",
                }
            },
            {
                "Button": {
                    "id": "porperty_model",
                    "imgsrc": "images/moreMenu/measure/sview_measure_porperty_model.png",
                    "title": "模型",
                    "onClick": "commandClickFun('porperty_model','MeasureDistanceCommand')",
                }
            },
            {
                "Button": {
                    "id": "exitAnnotate",
                    "imgsrc": "images/moreMenu/translation/sview_button_exit.png",
                    "title": "退出",
                    "onClick": "confirmExit('MeasureAttributesMenu')",
                }
            },
        ]
    }
}
//爆炸菜单
var ExplosiveMenu = {
    "BottomMenu": {
        "id": "explosive_menu",
        "classes": [
            "SView-bottomMenu",
        ],
        "subComponents": [
            {
                "Button": {
                    "id": "explosive_global",
                    "imgsrc": "images/moreMenu/explosive/sview_explosive_global.png",
                    "title": "爆炸方向",
                    "onClick": "showPopoverSelect('explosiveSelect')",
                    "subComponents": [{
                        "PopoverSelect": {
                            "id": "explosiveSelect",
                            "isShow": false,
                            "subComponents": [
                                {
                                    "Button": {
                                        "id": "centerExplosive",
                                        "imgsrc": "images/moreMenu/explosive/sview_explosive_global.png",
                                        "title": "中心爆炸",
                                        "onClick": "selectImg('explosiveDirection', 1)"
                                    }
                                },
                                {
                                    "Button": {
                                        "id": "xExplosive",
                                        "imgsrc": "images/moreMenu/explosive/sview_explosive_yzdirection.png",
                                        "title": "x轴线性爆炸",
                                        "onClick": "selectImg('explosiveDirection', 2)"
                                    }
                                },
                                {
                                    "Button": {
                                        "id": "yExplosive",
                                        "imgsrc": "images/moreMenu/explosive/sview_explosive_xzdirection.png",
                                        "title": "y轴线性爆炸",
                                        "onClick": "selectImg('explosiveDirection', 3)"
                                    }
                                },
                            ]
                        }
                    }
                    ]
                }
            },
            {
                "Slider": {
                    "id": "explosive_slider",
                    "sliderBar": {
                        "id": "explosive_sliderBar",
                        "min": 0,
                        "max": 100,
                        "step": 1,
                        "value": 0,
                    }
                }
            },
            {
                "Select": {
                    "id": "explosive_select",
                    "value": null,
                    "classes": [
                        "SView-select",
                        "explosiveGrade"
                    ],
                    "options": [
                        {
                            "Option": {
                                "value": null,
                                "content": "无"
                            }
                        },
                        {
                            "Option": {
                                "value": 0,
                                "content": 0
                            }
                        },
                        {
                            "Option": {
                                "value": 1,
                                "content": 1
                            }
                        },
                        {
                            "Option": {
                                "value": 2,
                                "content": 2
                            }
                        },
                        {
                            "Option": {
                                "value": 3,
                                "content": 3
                            }
                        },
                        {
                            "Option": {
                                "value": 4,
                                "content": 4
                            }
                        },
                        {
                            "Option": {
                                "value": 5,
                                "content": 5
                            }
                        }
                    ],
                    "onClick": "commandClickFun('sequence','AnnotationNumberCommand')",
                }
            },
            {
                "Button": {
                    "id": "exitAnnotate",
                    "imgsrc": "images/moreMenu/translation/sview_button_exit.png",
                    "title": "退出",
                    "onClick": "confirmExit('ExplosiveMenu')",
                }
            },
        ]
    }
}
//剖切菜单
var SectioneMenu = {
    "BottomMenu": {
        "id": "sectione_menu",
        "classes": [
            "SView-bottomMenu",
        ],
        "subComponents": [
            {
                "Button": {
                    "id": "sectione_global",
                    "imgsrc": "images/moreMenu/section/button_yzsection.png",
                    "title": "剖切方向",
                    "imgOnClick": "showPopoverSelect('sectionePopover')",
                    "subComponents": [{
                        "Popover": {
                            "id": "sectionePopover",
                            "isShow": false,
                            "classes": [
                                "SView-popover",
                                "SView-popover-up" // 弹出方向：up、down
                            ],
                            "subComponents": [
                                {
                                    "PopoverRow": {
                                        "id": "popoverRowSection_1",
                                        "subComponents": [
                                            {
                                                "Button": {
                                                    "id": "yzSection",
                                                    "imgsrc": "images/moreMenu/section/button_yzsection.png",
                                                    "title": "yz面剖切",
                                                    "onClick": "commandClickFun('yzSection', 1)"
                                                }
                                            },
                                            {
                                                "Button": {
                                                    "id": "yzSectionReverse_1",
                                                    "imgsrc": "images/moreMenu/section/button_sectionreversal.png",
                                                    "title": "剖切反向",
                                                    "onClick": "commandClickFun('yzSectionReverse_1', 2)"
                                                }
                                            },
                                            {
                                                "Slider": {
                                                    "id": "section_slider_1",
                                                    "sliderBar": {
                                                        "id": "section_sliderBar_1",
                                                        "min": 0,
                                                        "max": 100,
                                                        "step": 1,
                                                        "value": 0,
                                                    }
                                                }
                                            },
                                        ]
                                    }
                                },
                                {
                                    "PopoverRow": {
                                        "id": "popoverRowSection_2",
                                        "subComponents": [
                                            {
                                                "Button": {
                                                    "id": "xySection",
                                                    "imgsrc": "images/moreMenu/section/button_xysection.png",
                                                    "title": "xy面剖切",
                                                    "onClick": "commandClickFun('xySection', 1)"
                                                }
                                            },
                                            {
                                                "Button": {
                                                    "id": "xySectionReverse",
                                                    "imgsrc": "images/moreMenu/section/button_sectionreversal.png",
                                                    "title": "剖切反向",
                                                    "onClick": "commandClickFun('xySectionReverse', 2)"
                                                }
                                            },
                                            {
                                                "Slider": {
                                                    "id": "section_slider_2",
                                                    "sliderBar": {
                                                        "id": "section_sliderBar_2",
                                                        "min": 0,
                                                        "max": 100,
                                                        "step": 1,
                                                        "value": 0,
                                                    }
                                                }
                                            },
                                        ]
                                    }
                                },
                                {
                                    "PopoverRow": {
                                        "id": "popoverRowSection_3",
                                        "subComponents": [
                                            {
                                                "Button": {
                                                    "id": "zxSection",
                                                    "imgsrc": "images/moreMenu/section/button_zxsection.png",
                                                    "title": "zx面剖切",
                                                    "onClick": "commandClickFun('zxSection', 1)"
                                                }
                                            },
                                            {
                                                "Button": {
                                                    "id": "zxSectionReverse",
                                                    "imgsrc": "images/moreMenu/section/button_sectionreversal.png",
                                                    "title": "剖切反向",
                                                    "onClick": "commandClickFun('zxSectionReverse', 2)"
                                                }
                                            },
                                            {
                                                "Slider": {
                                                    "id": "section_slider_3",
                                                    "sliderBar": {
                                                        "id": "section_sliderBar_3",
                                                        "min": 0,
                                                        "max": 100,
                                                        "step": 1,
                                                        "value": 0,
                                                    }
                                                }
                                            },
                                        ]
                                    }
                                },
                            ]
                        }
                    }
                    ]
                }
            }, 
            {
                "Slider": {
                    "id": "all_section_slider",
                    "sliderBar": {
                        "id": "all_section_sliderBar",
                        "min": 0,
                        "max": 100,
                        "step": 1,
                        "value": 0,
                    }
                }
            },
            {
                "Button": {
                    "id": "allSectionReverse",
                    "imgsrc": "images/moreMenu/section/button_sectionreversal.png",
                    "title": "剖切反向",
                    "onClick": "commandClickFun('SectioneMenu')",
                }
            },
            {
                "Button": {
                    "id": "sectionPlane",
                    "imgsrc": "images/moreMenu/section/button_showsectionplane.png",
                    "title": "剖切面显隐",
                    "onClick": "commandClickFun('SectioneMenu')",
                }
            },
            {
                "Button": {
                    "id": "coverPlane",
                    "imgsrc": "images/moreMenu/section/sview_section_showcappingplane.png",
                    "title": "盖面显隐",
                    "onClick": "commandClickFun('SectioneMenu')",
                }
            },
            {
                "Button": {
                    "id": "addSection",
                    "imgsrc": "images/moreMenu/section/button_add.png",
                    "title": "添加剖切对象",
                    "onClick": "commandClickFun('SectioneMenu')",
                }
            },
            {
                "Button": {
                    "id": "clearSection",
                    "imgsrc": "images/moreMenu/section/button_clear.png",
                    "title": "清空剖切对象",
                    "onClick": "commandClickFun('SectioneMenu')",
                }
            },
            {
                "Button": {
                    "id": "exitAnnotate",
                    "imgsrc": "images/moreMenu/translation/sview_button_exit.png",
                    "title": "退出",
                    "onClick": "confirmExit('SectioneMenu')",
                }
            },
        ]
    }
}
// ---------- 移动主菜单 -----------
var MoveMenu = {
    "BottomMenu": {
        "id": "move_menu",
        "classes": [
            "SView-bottomMenu",
        ],
        "subComponents": [
            {
                "Button": {
                    "id": "move_global",
                    "imgsrc": "images/moreMenu/translation/sview_dragger_translation.png",
                    "title": "平移",
                    "imgOnClick": "showPopoverSelect('move_type')",
                    "subComponents": [{
                        "PopoverSelect": {
                            "id": "move_type",
                            "isShow": false,
                            "subComponents": [
                                {
                                    "Button": {
                                        "id": "translation",
                                        "imgsrc": "images/moreMenu/translation/sview_dragger_translation.png",
                                        "title": "平移",
                                        "highLight":true,
                                        "onClick": "selectImg('translation','move_global')"
                                    }
                                },
                                {
                                    "Button": {
                                        "id": "rotation",
                                        "imgsrc": "images/moreMenu/translation/sview_dragger_rotation.png",
                                        "title": "旋转",
                                        "onClick": "selectImg('rotation','move_global')"
                                    }
                                },
                                {
                                    "Button": {
                                        "id": "scaling",
                                        "imgsrc": "images/moreMenu/translation/sview_dragger_scaling.png",
                                        "title": "缩放",
                                        "onClick": "selectImg('scaling','move_global')"
                                    }
                                },
                            ]
                        }
                    }
                    ]
                }
            },
            {
                "Button": {
                    "id": "translation_dir",
                    "imgsrc": "images/moreMenu/translation/ssview_dragger_planetranslation.png",
                    "title": "沿平面",
                    "highLight": true,
                    "onClick": "selectTranslationDir('translation_dir',0)",
                }
            },
            {
                "Button": {
                    "id": "move_x",
                    "imgsrc": "images/moreMenu/translation/button_yzsection.png",
                    "title": "沿X轴",
                    "onClick": "selectTranslationDir('move_x',1)",
                }
            },
            {
                "Button": {
                    "id": "move_y",
                    "imgsrc": "images/moreMenu/translation/button_zxsection.png",
                    "title": "沿Y轴",
                    "onClick": "selectTranslationDir('move_y',2)",
                }
            },
            {
                "Button": {
                    "id": "move_z",
                    "imgsrc": "images/moreMenu/translation/button_xysection.png",
                    "title": "沿Z轴",
                    "onClick": "selectTranslationDir('move_z',3)",
                }
            },
            {
                "Button": {
                    "id": "exitAnnotate",
                    "imgsrc": "images/moreMenu/translation/sview_button_exit.png",
                    "title": "退出",
                    "onClick": "exitBottomMenu(MoveMenu)",
                }
            },
        ]
    }
}
// ---------- 手势批注主菜单 -----------
var GestureMenu = {
    "BottomMenu": {
        "id": "gesture_menu",
        "classes": [
            "SView-bottomMenu",
        ],
        "subComponents": [
            {
                "Button": {
                    "id": "gesture_global",
                    "imgsrc": "images/moreMenu/annotate/gesture/button_gesture3d_freedom.png",
                    "title": "线",
                    "imgOnClick": "showPopoverSelect('gestureType')",
                    "subComponents": [{
                        "PopoverSelect": {
                            "id": "gestureType",
                            "isShow": false,
                            "subComponents": [
                                {
                                    "Button": {
                                        "id": "gesture3d_freedom",
                                        "imgsrc": "images/moreMenu/annotate/gesture/button_gesture3d_freedom.png",
                                        "title": "线",
                                        "highLight": true,
                                        "onClick": "selectImg('gesture3d_freedom','gesture_global')"
                                    }
                                },
                                {
                                    "Button": {
                                        "id": "gesture3d_circle",
                                        "imgsrc": "images/moreMenu/annotate/gesture/button_gesture3d_circle.png",
                                        "title": "圆",
                                        "onClick": "selectImg('gesture3d_circle','gesture_global')"
                                    }
                                },
                                {
                                    "Button": {
                                        "id": "gesture3d_rect",
                                        "imgsrc": "images/moreMenu/annotate/gesture/button_gesture3d_rect.png",
                                        "title": "矩形",
                                        "onClick": "selectImg('gesture3d_rect','gesture_global')"
                                    }
                                },
                                {
                                    "Button": {
                                        "id": "gesture3d_triangle",
                                        "imgsrc": "images/moreMenu/annotate/gesture/button_gesture3d_triangle.png",
                                        "title": "三角形",
                                        "onClick": "selectImg('gesture3d_triangle','gesture_global')"
                                    }
                                },
                            ]
                        }
                    }
                    ]
                }
            },
            {
                "Button": {
                    "id": "gesture_color_info",
                    "imgsrc": "images/moreMenu/annotate/gesture/orange.png",
                    "title": "颜色",
                    "imgOnClick": "showPopoverSelect('gesture_color')",
                    "subComponents": [{
                        "PopoverSelect": {
                            "id": "gesture_color",
                            "isShow": false,
                            "classes": [
                                "SView-popoverSelect",
                                "SView-popoverSelect-up",
                                "SView-popoverSelect-tripleWidth"
                            ],
                            "subComponents": [
                                {
                                    "Button": {
                                        "id": "gesture_color_black",
                                        "imgsrc": "images/moreMenu/annotate/gesture/black.png",
                                        "title": "黑色",
                                        "onClick": "selectImg('gesture_color_black','gesture_color_info')"
                                    }
                                },
                                {
                                    "Button": {
                                        "id": "gesture_color_red",
                                        "imgsrc": "images/moreMenu/annotate/gesture/red.png",
                                        "title": "红色",
                                        "onClick": "selectImg('gesture_color_red','gesture_color_info')"
                                    }
                                },
                                {
                                    "Button": {
                                        "id": "gesture_color_blue",
                                        "imgsrc": "images/moreMenu/annotate/gesture/blue.png",
                                        "title": "蓝色",
                                        "onClick": "selectImg('gesture_color_blue','gesture_color_info')"
                                    }
                                },
                                {
                                    "Button": {
                                        "id": "gesture_color_green",
                                        "imgsrc": "images/moreMenu/annotate/gesture/green.png",
                                        "title": "绿色",
                                        "onClick": "selectImg('gesture_color_green','gesture_color_info')"
                                    }
                                },
                                {
                                    "Button": {
                                        "id": "gesture_color_yellow",
                                        "imgsrc": "images/moreMenu/annotate/gesture/yellow.png",
                                        "title": "黄色",
                                        "onClick": "selectImg('gesture_color_yellow','gesture_color_info')"
                                    }
                                },
                                {
                                    "Button": {
                                        "id": "gesture_color_orange",
                                        "imgsrc": "images/moreMenu/annotate/gesture/orange.png",
                                        "title": "橙色",
                                        "highLight":true,
                                        "onClick": "selectImg('gesture_color_orange','gesture_color_info')"
                                    }
                                },
                                {
                                    "Button": {
                                        "id": "gesture_color_gray",
                                        "imgsrc": "images/moreMenu/annotate/gesture/gray.png",
                                        "title": "灰色",
                                        "onClick": "selectImg('gesture_color_gray','gesture_color_info')"
                                    }
                                },
                                {
                                    "Button": {
                                        "id": "gesture_color_purple",
                                        "imgsrc": "images/moreMenu/annotate/gesture/purple.png",
                                        "title": "紫色",
                                        "onClick": "selectImg('gesture_color_purple','gesture_color_info')"
                                    }
                                },
                                {
                                    "Button": {
                                        "id": "gesture_color_brown",
                                        "imgsrc": "images/moreMenu/annotate/gesture/brown.png",
                                        "title": "棕色",
                                        "onClick": "selectImg('gesture_color_brown','gesture_color_info')"
                                    }
                                },
                                {
                                    "Button": {
                                        "id": "gesture_color_pink",
                                        "imgsrc": "images/moreMenu/annotate/gesture/pink.png",
                                        "title": "粉色",
                                        "onClick": "selectImg('gesture_color_pink','gesture_color_info')"
                                    }
                                },
                                {
                                    "Button": {
                                        "id": "gesture_color_default",
                                        "imgsrc": "images/moreMenu/annotate/gesture/default.png",
                                        "title": "白色",
                                        "onClick": "selectImg('gesture_color_default','gesture_color_info')"
                                    }
                                },
                            ]
                        }
                    }]
                }
            },
            {
                "Button": {
                    "id": "gesture_width_type",
                    "imgsrc": "images/moreMenu/annotate/gesture/button_gesture3D_width.png",
                    "title": "粗细",
                    "imgOnClick": "showPopoverSelect('gesture_width')",
                    "subComponents": [{
                        "PopoverSelect": {
                            "id": "gesture_width",
                            "isShow": false,
                            "subComponents": [
                                {
                                    "Button": {
                                        "id": "gesture_width_thin",
                                        "imgsrc": "images/moreMenu/annotate/gesture/thin_line.png",
                                        "title": "细",
                                        "onClick": "selectImg('gesture_width_thin','gesture_width_type')"
                                    }
                                },
                                {
                                    "Button": {
                                        "id": "gesture_width_middle",
                                        "imgsrc": "images/moreMenu/annotate/gesture/middle_line.png",
                                        "title": "中",
                                        "onClick": "selectImg('gesture_width_middle','gesture_width_type')"
                                    }
                                },
                                {
                                    "Button": {
                                        "id": "gesture_width_strong",
                                        "imgsrc": "images/moreMenu/annotate/gesture/strong_line.png",
                                        "title": "粗",
                                        "onClick": "selectImg('gesture_width_strong','gesture_width_type')"
                                    }
                                },
                            ]
                        }
                    }]
                }
            },
            {
                "Button": {
                    "id": "sview_undo",
                    "imgsrc": "images/moreMenu/annotate/gesture/sview_undo.png",
                    "title": "撤销",
                    "onClick": "undoGestureNote()",
                }
            },
            {
                "Button": {
                    "id": "button_gesture3D_confirm",
                    "imgsrc": "images/moreMenu/annotate/gesture/button_gesture3D_confirm.png",
                    "title": "确定",
                    "onClick": "confirmGestureNote()",
                }
            },
            {
                "Button": {
                    "id": "gesture_width_exit",
                    "imgsrc": "images/moreMenu/translation/sview_button_exit.png",
                    "title": "退出",
                    "onClick": "exitBottomMenu(GestureMenu,AnnotateMenu)",
                }
            },
        ]
    }
}
//动画菜单
var AnimationMenu = {
    "BottomMenu": {
        "id": "animation_menu",
        "classes": [
            "SView-bottomMenu",
        ],
        "subComponents": [
            {
                "Button": {
                    "id": "ani_play",
                    "imgsrc": "images/moreMenu/animation/button_ani_play.png",
                    "title": "开始",
                    "onClick": "commandClickFun('AnimationMenu')",
                }
            },
            {
                "Slider": {
                    "id": "ani_slider",
                    "sliderBar": {
                        "id": "ani_sliderBar",
                        "min": 0,
                        "max": 100,
                        "step": 1,
                        "value": 0,
                    }
                }
            },
            {
                "Button": {
                    "id": "ani_pre",
                    "imgsrc": "images/moreMenu/animation/sview_ani_pre.png",
                    "title": "后退",
                    "onClick": "commandClickFun('AnimationMenu')",
                }
            },
            {
                "Button": {
                    "id": "ani_next",
                    "imgsrc": "images/moreMenu/animation/sview_ani_next.png",
                    "title": "前进",
                    "onClick": "commandClickFun('AnimationMenu')",
                }
            },
            {
                "Button": {
                    "id": "ani_more",
                    "imgsrc": "images/moreMenu/animation/sview_ani_more.png",
                    "title": "更多",
                    "imgOnClick": "showPopoverSelect('animation_popover')",
                    "subComponents": [{
                        "Popover": {
                            "id": "animation_popover",
                            "isShow": false,
                            "classes": [
                                "SView-popover",
                                "SView-popover-up",// 弹出方向：up、down
                                "animationSetting"
                            ],
                            "subComponents": [
                                {
                                    "PopoverRow": {
                                        "id": "play_loop",
                                        "subComponents": [
                                            {
                                                "Label": "循环播放"
                                            },
                                            {
                                                "Checkbox": {
                                                    "id": "play_loop_checkbox",
                                                    "checkboxId": "play_loop_checkbox_label" // 复选框input标签id
                                                }
                                            },
                                            
                                        ]
                                    }
                                },
                                {
                                    "PopoverRow": {
                                        "id": "play_speed",
                                        "subComponents": [
                                            {
                                                "Label": "播放速度"
                                            },
                                            {
                                                "Select": {
                                                    "id": "play_speed_select",
                                                    "value": 1,
                                                    "classes": [
                                                        "SView-select",
                                                        "play_speed_grade"
                                                    ],
                                                    "options": [
                                                        {
                                                            "Option": {
                                                                "value": 0.5,
                                                                "content": "0.5x"
                                                            }
                                                        },
                                                        {
                                                            "Option": {
                                                                "value": 1,
                                                                "content": "1x"
                                                            }
                                                        },
                                                        {
                                                            "Option": {
                                                                "value": 2,
                                                                "content": "2x"
                                                            }
                                                        },
                                                        {
                                                            "Option": {
                                                                "value": 4,
                                                                "content":"4x"
                                                            }
                                                        },
                                                        {
                                                            "Option": {
                                                                "value": 8,
                                                                "content": "8x"
                                                            }
                                                        },
                                                    ],
                                                    "onClick": "commandClickFun()",
                                                }
                                            },
                                        ]
                                    }
                                },
                                {
                                    "PopoverRow": {
                                        "id": "auto_walking",
                                        "subComponents": [
                                            {
                                                "Label": "自动漫游"
                                            },
                                            {
                                                "Checkbox": {
                                                    "id": "auto_walking_checkbox",
                                                    "checkboxId": "auto_walking_checkbox_label" // 复选框input标签id
                                                }
                                            },

                                        ]
                                    }
                                },
                            ]
                        }
                    }
                    ]
                }
            },
            {
                "Button": {
                    "id": "exitAnnotate",
                    "imgsrc": "images/moreMenu/translation/sview_button_exit.png",
                    "title": "退出",
                    "onClick": "exitBottomMenu(AnimationMenu)",
                }
            },
        ]
    }
}