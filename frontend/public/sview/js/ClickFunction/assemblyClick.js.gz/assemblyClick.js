var tree;
var treeConfig = {
    isCopy: false,
    isCut: false,
    node: ""
}
/* ------------------ 打开装配树 ------------------- */
function showAssemblyTree(elementId) {
    var treeMenu = document.getElementById(AssemblyDialog.TreeDialog.id);
    let uiManager = sview0.sviewFrame.getUIManager();
    SView.Windows.Button.highLightLabel(elementId);
    if (treeMenu == null) {
        var base = sview0.sviewFrame.getViewer().scene;
        var topModel = base.getTopModel("http://10.0.43.166:8082/SView/SView/models/3d_pmi.svlx");
        var data = AssemblyDialog.TreeDialog.content_1.subComponents[0].Tree.data;
        //AssemblyDialog.TreeDialog.content_1.subComponents[0].Tree.data = [];
        //AssemblyDialog.TreeDialog.content_1.subComponents[0].Tree.data[0] = new S3DView.JsonAssembly(topModel, true, true);
        uiManager.load(AssemblyDialog);
        var option = {
            data: data,
            checkbox: true,
            elem: '.SView-tree-content',
            fold: function () { },
            unfold: function () { },
            format: function (format) {
                format.id = 'id';
                format.data = 'all';
                format.name = 'name';
                format.title = 'all';
                format.childs = 'children';
                f = format;
            },
            loadText: '正在加载数据中，请稍后...',
            loadCallBack: function (tree) {
                tree.getNodeById(data[0].id).unFold();
            },
            toolClick: function (type, node) {

            },
            folder_click: function (node) {

            },
            gm_click: function (node) {
                tree.setNodeSelect(node);
            },
            gm_contextmenu: function (node) {
                tree.setNodeSelect(node);
                nodeRightClick(node.elem, "treeRightClickMenu");
            },
            loadAll: true,
            template: function (data) {

            },
        };
        tree = new Tree(option);
        tree.init();
        document.getElementById(AssemblyDialog.TreeDialog.id).oncontextmenu = function (e) {
            e = e || window.event;
            event.cancelBubble = true;
            if (e.preventDefault) {
                e.preventDefault()
            } else {
                window.event.returnValue = false //兼容IE6、7、8
            }
            return false;
        }
    } else if (treeMenu.style.display == "" || treeMenu.style.display == "block") {
        treeMenu.style.display = "none";
    } else {
        treeMenu.style.display = "block";
    }
}
//装配树和视图列表切换
function changeTreeTabs(elementId, dataClass) {
    let tabs = document.getElementById(elementId);
    // 标签按钮
    let btns = tabs.getElementsByTagName("div");
    // 标签内容
    let tabContent = document.getElementById(dataClass);
    // 按钮高亮
    for (var i = 0; i < btns.length; i++) {
        let btnDataClass = btns[i].dataset.class;
        if (btnDataClass == dataClass) {
            tabContent.style.display = "";
            tabContent.dataset.active = "true";
            btns[i].style.backgroundColor = "rgba(44,135,255, .5)";
        } else {
            btns[i].style.backgroundColor = "";
            let hiddenContent = document.getElementById(btnDataClass);
            hiddenContent.dataset.active = "false";
            hiddenContent.style.display = "none";
        }
    }
}
//创建视图
function createView() {
    rightClickMenu(false);
    let uiManager = sview0.sviewFrame.getUIManager();
    uiManager.load(CreateView);
}
function selectView(id, e) {
    if (e && e.stopPropagation) {
        e.stopPropagation();
        e.preventDefault();
    } else {
        window.event.cancelBubble = true;
    }
}
//编辑视图
function editView(val, type, e) {
    if (e && e.stopPropagation) {
        e.stopPropagation();
        e.preventDefault();
    } else {
        window.event.cancelBubble = true;
    }
    if (type == 0) {

    } else if (type == 1) {
        rightClickMenu(false);
        let uiManager = sview0.sviewFrame.getUIManager();
        uiManager.load(CreateView);
        document.getElementById("createViewName").value = val.name;
        //document.getElementsByClassName("SView-view-" + val)[0].querySelector("span").innerHTML;
    } else if (type == 2) {
        DeleteDialog.Dialog.content = "是否设置为默认视图？";
        DeleteDialog.Dialog.buttons[0].onClick = "deleteView('confirm-delete')";
        sview0.sviewFrame.getUIManager().load(DeleteDialog);
    } else if (type == 3) {
        DeleteDialog.Dialog.content = "确定删除选中的视图吗？";
        DeleteDialog.Dialog.buttons[0].onClick = "deleteView('confirm-delete')";
        sview0.sviewFrame.getUIManager().load(DeleteDialog);
    }
}
/* ------------------ 装配树右键相关方法 ------------------- */
//添加装配
var isOver = true;
var asmFileInput = null;
asmFileInput = document.createElement("input");
asmFileInput.type = 'file';
asmFileInput.id = "addAssemblyFile";
asmFileInput.accept = '.zip, .svp, .svlx, .zsvl';
asmFileInput.multiple = false;
asmFileInput.addEventListener('change', function () {
    if (asmFileInput.files.length < 1) {
        return;
    }
    var type = asmFileInput.files[0].name.split(".").pop().toLowerCase();
    if (type == "zsvl" || type == "svlx" || type == "svp" || type == "zip") {
        event.preventDefault();
        event.stopPropagation();
        isAssemlyOpen = true;
        isOver = false;
        var readState =reader.assemblyAdd(asmFileInput.files);
        if (readState !== "OK") {
            CreateWarningWindow(false, "Prompt", "SelectBin");
            asmFileInput.value = '';
        }
    } else {
        CreateWarningWindow(false, "Assembly", "Assembly_add_file_error");
        asmFileInput.value = '';
    }
});
function addAsemble() {
    if (!isOver) {
        showResultDialog('loading', '', '请稍候...！');
        return;
    }
    var id = tree.getSelected();
    //if (shape.GetSubModelCount() == 0) {
    //    //CreateInfoWindow(null, getLocalizedString(language, "Alert", "Alert_Prompt"),
    //    //    getLocalizedString(language, "Assembly", "SelectAssembly"));
    //    CreateRemindWindow(event, "Prompt", "AssemblyCanAddModel");
    //    return;
    //}
    //sview.GetSelector().Add(shape);
    asmFileInput.click();
}
// 树形控件重命名
function nodeRename() {
    var node = tree.getSelected();
    node.elem.querySelector(".tree-title").style.display = "none";
    node.elem.querySelector("input").style.display = "inline-block";
    node.elem.querySelector("input").focus();
}
//复制
function copyAsemble() {
    var selectedNoedes = tree.getSelected();
    //var shape = sview.GetShpae(selectedNoedes.id);
    //var topModel = sview.view.GetSceneManager().GetModel();
    //if (shape.GetID() == topModel.GetID()) {
    //    CreateRemindWindow(event, "Prompt", "TopAssemblyCannotCopy");
    //    return;
    //}
    //showResultDialog('warning','','顶级模型不能复制！')
    treeConfig.isCopy = true;
    treeConfig.isCut = false;
    treeConfig.node = selectedNoedes;
}
//剪切
function cutAsemble() {
    var selectedNoedes = tree.getSelected();
    //var shape = sview.GetShpae(selectedNoedes.id);
    //var topModel = sview.view.GetSceneManager().GetModel();
    //if (shape.GetID() == topModel.GetID()) {
    //    CreateRemindWindow(event, "Prompt", "TopAssemblyCannotCopy");
    //    return;
    //}
    //showResultDialog('warning', '', '顶级模型不能复制！')
    treeConfig.isCopy = false;
    treeConfig.isCut = true;
    treeConfig.node = selectedNoedes;
}
//粘贴
function pasteAsemble() {
    //如果没有复制/剪切，则返回
    if (!treeConfig.isCopy && !treeConfig.isCut) {
        showResultDialog('warning', '', '剪切板为空，无法粘贴！')
        //CreateRemindWindow(event, "Prompt", "ClipboardIsEmpty");
        return;
    }
    var treeObj = $.fn.zTree.getZTreeObj(assemblyTreeId);
    var selectedNoedes = treeObj.getSelectedNodes();
    //原模型
    var shape = sview.GetShpae(ztreeConfig.node.id);
    //目标模型
    var targetShape = sview.GetShpae(selectedNoedes[0].id);
    //如果目标模型不是装配，则返回
    if (targetShape.GetSubModelCount() == 0) {
        //alert(getLocalizedString(language, "Assembly", "SelectAssembly"));
        //CreateInfoWindow(null, getLocalizedString(language, "Alert", "Alert_Prompt"),
        //    getLocalizedString(language, "Assembly", "SelectAssembly"));
        CreateRemindWindow(event, "Prompt", "PleaseSelectAssembly");
        return;
    }
    //如果选择的是同一个模型则返回
    if (shape.GetID() == targetShape.GetID()) {
        //alert(getLocalizedString(language, "Assembly", "CelectOtherAssembly"));
        //CreateInfoWindow(null, getLocalizedString(language, "Alert", "Alert_Prompt"),
        //    getLocalizedString(language, "Assembly", "CelectOtherAssembly"));
        CreateRemindWindow(event, "Prompt", "PeerAssemblyCannotPaste");
        return;
    }
    //如果原模型包含目标模型则返回
    if (isChildModel(shape, targetShape, isChild)) {
        //alert(getLocalizedString(language, "Assembly", "CelectOtherAssembly"));
        //CreateInfoWindow(null, getLocalizedString(language, "Alert", "Alert_Prompt"),
        //    getLocalizedString(language, "Assembly", "CelectOtherAssembly"));
        CreateRemindWindow(event, "Prompt", "CircularReference");
        return;
    }
    //复制
    if (ztreeConfig.isCopy) {
        var outShape = null;
        sview.AssemblyCopyTo(shape, targetShape, outShape);
        //sview.GetBomManager().CopyTo(shape, targetShape);
        //ztreeConfig.isCopy = false;
        //ztreeConfig.node = "";
    }
    //剪切
    if (ztreeConfig.isCut) {
        sview.AssemblyMoveTo(shape, targetShape);
        //sview.GetBomManager().MoveTo(shape, targetShape);
        var modeljson = new SView.JSONAssembly(shape, true, true);
        treeObj.addNodes(selectedNoedes[0], modeljson);
        treeObj.removeNode(ztreeConfig.node, false);
        ztreeConfig.isCut = false;
        ztreeConfig.node = "";
    }

}
//卸载和加载
function loadOrUnload(type) {
    var id = tree.getSelected().id;
    tree.setInstall(id, type);
}
//删除
function confirmRemoveAsemble() {
    var selectedNoedes = tree.getSelected();
    DeleteDialog.Dialog.content = "确认删除" + selectedNoedes.name +"吗？";
    DeleteDialog.Dialog.buttons[0].Button.onClick = "removeAsemble('confirm-delete')";
    sview0.sviewFrame.getUIManager().load(DeleteDialog);
}
function removeAsemble(elementId) {
    var selectedNoedes = tree.getSelected();
    selectedNoedes.remove();
    sview0.sviewFrame.getUIManager().removeLabel(elementId);
}
//剪切
function cutAsemble() {
    var selectedNoedes = tree.getSelected();
    //var shape = sview.GetShpae(selectedNoedes.id);
    //var topModel = sview.view.GetSceneManager().GetModel();
    //if (shape.GetID() == topModel.GetID()) {
    //    CreateRemindWindow(event, "Prompt", "TopAssemblyCannotCopy");
    //    return;
    //}
    //showResultDialog('warning', '', '顶级模型不能复制！')
    treeConfig.isCopy = false;
    treeConfig.isCut = true;
    treeConfig.node = selectedNoedes;
}
// //oncontextmenu上下文菜单事件，右键菜单
function nodeRightClick(e, rightClickMenuId) {
    var treeRightMenu = document.getElementById(rightClickMenuId);
    //显示我们自己定义的右键菜单
    //1.找到菜单
    //提取到函数外面作为全局变量

    //兼容Event对象
    e = e || window.event;
    event.cancelBubble = true;
    if (e.preventDefault) {
        e.preventDefault()
    } else {
        window.event.returnValue = false //兼容IE6、7、8
    }
    //鼠标坐标
    var offsetObj = offset(e);
    treeRightMenu.style.left = (offsetObj.l + 40) + "px";
    treeRightMenu.style.top = (offsetObj.t + 20) + "px";
    //3.显示右键菜单
    treeRightMenu.style.display = "block";
    //阻止默认的右键菜单显示
    return false;
};
/* ------------------ 检查输入框内容长度 ------------------- */
function checkLength(elementId, id) {
    var element = document.getElementById(elementId);
    var fatherElement = element.parentNode;
    var warning = fatherElement.getElementsByClassName("SView-warningPopover")[0];
    if (warning != null && element.value == "") {
        warning.style.display = "";
        setTimeout(function () {
            warning.style.display = "none";
        }, 3000)
    } else {
        warning = fatherElement.getElementsByTagName("p")[0];
        if (element.value.length == 0) {
            warning.style.display = "";
        } else {
            warning.style.display = "none";
            if (id == AssemblyDialog.TreeDialog.id) {
                var node = tree.getNodeByName(element.value);
                tree.setNodeSelect(node);
            }
        }
    }
    if (elementId == "meetingNickName") {
        nickName = element.value;
    }
}

