/* ------------------ 提示信息框 ------------------- */
function showResultDialog(type, title, content) {
    SuccessInfo.ResultDialog.icon.type = type;
    SuccessInfo.ResultDialog.titleContent = title;
    SuccessInfo.ResultDialog.detailContent = content;
    let uiManager = sview0.sviewFrame.getUIManager();
    var resultDialog = document.getElementById(SuccessInfo.ResultDialog.id);
    let resultElement;
    if (resultDialog == null) {
        uiManager.load(SuccessInfo);
        resultElement = uiManager.getElement(SuccessInfo.ResultDialog.id);
    } else {
        resultElement = uiManager.getElement(SuccessInfo.ResultDialog.id);
        resultElement.setTitle(title);
        resultElement.setDetail(content);
        resultElement.setImgsrc("./images/info/"+type+".png");
        resultElement.show();
    }
    setTimeout(function () { resultElement.hide(); }, 5000);
}
/* ------------------ 关闭弹窗 ------------------- */
function closeDialog(elementId, btnId = null) {
    rightClickMenu(true);
    // 删除相应标签
    sview0.sviewFrame.getUIManager().removeLabel(elementId);
    // 隐藏相应标签
    // sview0.sviewFrame.getUIManager().hideLabel(elementId);
    // 对应按钮取消高亮
    if (btnId != null) {
        SView.Windows.Button.highLightLabel(btnId);
    }
    var meetingDialog = document.getElementById(MeetingDialog.MeetingDialog.id);
    if (meetingDialog) {
        meetingDialog.style.display = "block";
    }
}

/* ------------------ 打开底部菜单栏 ------------------- */
var currBottomMenu;  // 当前底部菜单
function showBottomMenu(elementId) {
    var mainBottomMenu = document.getElementById(MainBottomMenu.BottomMenu.id);
    SView.Windows.Button.highLightLabel(elementId);
    if (mainBottomMenu == null) {
        // 创建底部菜单
        mainBottomMenu = sview0.sviewFrame.getUIManager().load(MainBottomMenu);
        currBottomMenu = "mainBottomMenu"
    } else {
        // 删除底部菜单
        sview0.sviewFrame.getUIManager().removeLabel(currBottomMenu);
        mainBottomMenu = null;
        currBottomMenu = null;
    }
}


// 需要隐藏右侧菜单的底部菜单ID
var hiddenRightMenu = ["move_menu", "sectione_menu", "explosive_menu", "annotate_menu", "measure_distance_menu", "animation_menu","gesture_menu","measure_distance_menu","measure_angle_menu", "measure_diameter_menu", "measure_attributes_menu"];
/* ------------------ 进入下一级底部菜单 ------------------- */
function enterBottomMenu(enterMenu, currentMenu = MainBottomMenu) {
    // 创建下一级菜单
    sview0.sviewFrame.getUIManager().load(enterMenu);
    currBottomMenu = enterMenu.BottomMenu.id;
    // 隐藏当前底部菜单
    sview0.sviewFrame.getUIManager().hideLabel(currentMenu.BottomMenu.id);
    // 隐藏右侧菜单
    if (hiddenRightMenu.indexOf(enterMenu.BottomMenu.id) != -1) {
        sview0.sviewFrame.getUIManager().hideLabel(RightMenu.RightMenu.id);
    }
}

/* ------------------ 确认删除弹出框 ------------------- */
function confirmDelete(elementId) {
    if (elementId == 'deleteAnnotate') {
        DeleteDialog.Dialog.content = "确认删除选中批注吗？";
        DeleteDialog.Dialog.buttons[0].onClick = "deleteAnnotate('confirm-delete')";
    }
    if (elementId == 'deleteMeasure') {
        DeleteDialog.Dialog.content = "确认删除选中的测量吗？";
        DeleteDialog.Dialog.buttons[0].onClick = "deleteAnnotate('confirm-delete')";
    }
    if (elementId == 'clearAnnotates') {
        DeleteDialog.Dialog.content = "批注对象删除后,将不可恢复,确定要删除所有批注对象吗?";
        DeleteDialog.Dialog.buttons[0].onClick = "deleteAnnotate('confirm-delete')";
    }
    if (elementId == 'clearMeasurements') {
        DeleteDialog.Dialog.content = "测量对象删除后,将不可恢复,确定要删除所有测量对象吗?";
        DeleteDialog.Dialog.buttons[0].onClick = "deleteAnnotate('confirm-delete')";
    }
    if (elementId == 'clearSectionPlanes') {
        DeleteDialog.Dialog.content = "剖切面删除后,将不可恢复,确定要删除所有剖切面吗?";
        DeleteDialog.Dialog.buttons[0].onClick = "deleteAnnotate('confirm-delete')";
    }
    sview0.sviewFrame.getUIManager().load(DeleteDialog);
}

/* ------------------ 确认退出弹出框 ------------------- */
function confirmExit(exitDialog) {
    if (exitDialog) {
        ExitDialog.Dialog.content = language.Prompt.ExitCurrentOperation;
        ExitDialog.Dialog.buttons[0].Button.onClick = "exitBottomMenu(" + exitDialog + ")";
    }
    sview0.sviewFrame.getUIManager().load(ExitDialog);
}
/* ------------------ 折叠面板关闭打开 ------------------- */
function collapseClose(e) {
    // console.log(e);
    if (e.getElementsByClassName("SView-icon-open").length > 0) {
        e.getElementsByClassName("SView-icon-open")[0].setAttribute("class", "SView-icon-close");
        e.nextElementSibling.style.display = "none";
    } else {
        e.getElementsByClassName("SView-icon-close")[0].setAttribute("class", "SView-icon-open");
        e.nextElementSibling.style.display = "block";
    }
}

/* ------------------ 切换标签页 ------------------- */
function changeTabs(elementId, dataClass) {
    let tabs = document.getElementById(elementId);
    let tabElement = tabs.getElementsByClassName("SView-tabs")[0].children;
    for (let i = 0; i < tabElement.length; i++) {
        let tabContent = document.getElementById(tabElement[i].dataset.class);
        // 更改选中标签样式
        if (tabElement[i].dataset.class != dataClass) {
            tabElement[i].dataset.active = "false";
            tabElement[i].setAttribute("class", "SView-tab");
            // 关闭该标签内容
            tabContent.style.display = "none";
        } else {
            tabElement[i].dataset.active = "true";
            tabElement[i].setAttribute("class", "SView-tab SView-tab-active");
            // 显示该标签
            tabContent.style.display = "";
        }
    }
}
/* ------------------ 打开视图菜单 ------------------- */
function showViewMenu(elementId) {
    var viewMenu = document.getElementById(ViewMenu.ViewMenu.id);
    SView.Windows.Button.highLightLabel(elementId);
    let uiManager = sview0.sviewFrame.getUIManager();
    if (viewMenu == null) {
        // 创建视图菜单
        viewMenu = uiManager.load(ViewMenu);
    } else {
        // 删除视图菜单
        uiManager.removeLabel(ViewMenu.ViewMenu.id);
        attributeMenu = null;
    }
}
//视图菜单点击
function selectRenderMode(id,type) {
    var dirs = document.getElementById(id).parentElement.parentElement.children;
    for (var i = 0; i < dirs.length; i++) {
        dirs[i].children[0].style.backgroundColor = "";
    }
    SView.Windows.Button.highLightLabel(id);
}
//漫游模式
function selectWalkingMode(id) {
    SView.Windows.Button.highLightLabel(id);
}
/* ------------------ 打开属性菜单 ------------------- */
function showAttributeInfo(elementId) {
    var attributeMenu = document.getElementById(AttributeDialog.AttributeDialog.id);
    SView.Windows.Button.highLightLabel(elementId);
    let uiManager = sview0.sviewFrame.getUIManager();
    if (attributeMenu == null) {
        // 创建属性菜单
        attributeMenu = uiManager.load(AttributeDialog);
        bindDragEvent(AttributeDialog.AttributeDialog.id);
    } else {
        // 删除属性菜单
        uiManager.removeLabel(AttributeDialog.AttributeDialog.id);
        attributeMenu = null;
    }
}
/* ------------------ 打开协同会议 ------------------- */
function showMeetingMenu(elementId) {
    var meetingDialog = document.getElementById(MeetingDialog.MeetingDialog.id);
    SView.Windows.Button.highLightLabel(elementId);
    let uiManager = sview0.sviewFrame.getUIManager();
    if (meetingDialog == null) {
        // 创建属性菜单
        meetingDialog = uiManager.load(MeetingDialog);
        bindDragEvent(MeetingDialog.MeetingDialog.id);
    } else {
        // 删除属性菜单
        uiManager.removeLabel(MeetingDialog.MeetingDialog.id);
        meetingDialog = null;
    }
}
// 为元素 绑定拖动事件
function bindDragEvent(id) {
    var setObj = document.getElementById(id).querySelector(".SView-dialog-title");
    var obj = document.getElementById(id).querySelector(".SView-dialog");
    setObj.onmousedown = function (e) {
        e = e || window.event;

        setObj.setCapture && setObj.setCapture();    // IE8 及以下 强制捕获下一次单击事件

        obj.fixedX = e.clientX - (obj.getBoundingClientRect().left - document.documentElement.clientLeft);
        obj.fixedY = e.clientY - (obj.getBoundingClientRect().top - document.documentElement.clientTop);

        document.onmousemove = function (e) {
            e = e || window.event;

            var x = e.clientX + (document.documentElement.scrollLeft || window.pageXOffset || document.body.scrollLeft);
            var y = e.clientY + (document.documentElement.scrollTop || window.pageYOffset || document.body.scrollTop);

            obj.style.left = x - obj.fixedX + "px";    // 元素在页面中的坐标 = 鼠标在页面中的坐标 - 元素在页面中的坐标
            obj.style.top = y - obj.fixedY + "px";
        };

        document.onmouseup = function () {
            document.onmousemove = null;    // 解除 鼠标移动div跟随 事件
            document.onmouseup = null;    // 解除鼠标松开事件
            setObj.releaseCapture && setObj.releaseCapture();    // IE8 及以下 解除强制捕获单击事件
        };

        return false;
    };
}
/* ------------------ 检查输入框内容长度 ------------------- */
function checkLength(elementId,id) {
    var element = document.getElementById(elementId);
    var fatherElement = element.parentNode;
    var warning = fatherElement.getElementsByClassName("SView-warningPopover")[0];
    if (warning != null && element.value == "") {
        warning.style.display = "";
        setTimeout(function () {
            warning.style.display = "none";
        }, 3000)
    } else {
        warning = fatherElement.getElementsByTagName("p")[0];
        if (element.value.length == 0) {
            warning.style.display = "";
        } else {
            warning.style.display = "none";
            if (id == AssemblyDialog.TreeDialog.id) {
                var node = tree.getNodeByName(element.value);
                tree.setNodeSelect(node);
            }
        }
    }
    if (elementId == "meetingNickName") {
        nickName = element.value;
    }
}

// //自定义一个浏览器右键菜单，单击右键是显示它
function offset(ele) {
    var obj = { t: 0, l: 0 };
    obj.l = ele.offsetLeft;
    obj.t = ele.offsetTop;

    while (ele.offsetParent) {//寻找父级，当寻找到 body 往上的时候为 null ，所以循环停止
        ele = ele.offsetParent; //初始值
        obj.l += ele.offsetLeft
        obj.t += ele.offsetTop
    }

    return obj
}
//自定义一个浏览器右键菜单，单击右键是显示它
//oncontextmenu上下文菜单事件，右键菜单
function rightClickMenu(type) {
    if (type) {
        var rm;
        document.documentElement.oncontextmenu = function (e) {
            //显示我们自己定义的右键菜单
            let viewPort = sview0.sviewFrame.getViewer().getTouchViewport(e);
            let selector = viewPort.getScene().getSelector();
            let shapeList = selector.getAll();
            if (shapeList && shapeList.length > 0) {
                rm = document.getElementById(RightClickSelectMenu.RightClickMenu.id);
            } else {
                rm = document.getElementById(RightClickMenu.RightClickMenu.id);
            }
            //1.找到菜单
            //兼容Event对象
            e = e || window.event;
            e.stopPropagation();
            //2.设置菜单的位置等于鼠标的坐标
            //判断：如果鼠标的位置+菜单的宽度>网页的宽度，那么就改为右边定位
            //鼠标坐标
            var mx = e.clientX;
            var my = e.clientY;
            //菜单宽度
            var rmWidth = 127;
            //网页的宽度(高度用同样的方法解决)
            var pageWidth = document.documentElement.clientWidth;
            //console.log(pageWidth);
            if ((mx + rmWidth) < pageWidth) {
                rm.style.left = mx + "px";
                rm.style.top = my + "px";
            }
            else {
                rm.style.right = mx + "px";
                rm.style.top = my + "px";
            }
            //3.显示右键菜单
            rm.style.display = "block";
            //阻止默认的右键菜单显示
            return false;
        };
        //不需要积隐藏右键菜单
        document.documentElement.onclick = function () {
            if (rm && rm.style) {
                rm.style.display = "none";
            }
        }
    } else {
        document.documentElement.oncontextmenu = function (e) {
            return false;
        }
    }
}



//右键菜单相关方法
function showSettingColor() {
    rightClickMenu(false);
    var colorDialog = document.getElementById(ColorDialog.Dialog.id);
    let uiManager = sview0.sviewFrame.getUIManager();
    if (colorDialog == null) {
        colorDialog = uiManager.load(ColorDialog);
        Colorpicker.create({
            el: "color-picker", //元素id
            color: "#000fff", //默认颜色
            change: function (elem, hex) {
                //选中颜色发生改变时事件
                // elem.style.backgroundColor = hex;
            }
        })
    } else {
        uiManager.removeLabel(ColorDialog.Dialog.id);
        colorDialog = null;
    }
}
//会议相关
function showMeetingDialog(id,dialog) {
    rightClickMenu(false);
    document.getElementById(id).style.display = "none";
    let uiManager = sview0.sviewFrame.getUIManager();
    uiManager.load(dialog);
}
//设置
function showSettingMenu() {
    rightClickMenu(false);
    let uiManager = sview0.sviewFrame.getUIManager();
    uiManager.load(SettingDialog);
    bindDragEvent(SettingDialog.Dialog.id);
}
