// 需要隐藏右侧菜单的底部菜单ID
var hiddenRightMenu = ["move_menu", "sectione_menu", "explosive_menu", "annotate_menu", "measure_distance_menu", "animation_menu", "gesture_menu", "measure_distance_menu", "measure_angle_menu", "measure_diameter_menu", "measure_attributes_menu"];
/* ------------------ 进入下一级底部菜单 ------------------- */
function enterBottomMenu(enterMenu, currentMenu = MainBottomMenu) {
    // 创建下一级菜单
    sview0.sviewFrame.getUIManager().load(enterMenu);
    currBottomMenu = enterMenu.BottomMenu.id;
    // 隐藏当前底部菜单
    sview0.sviewFrame.getUIManager().hideLabel(currentMenu.BottomMenu.id);
    // 隐藏右侧菜单
    if (hiddenRightMenu.indexOf(enterMenu.BottomMenu.id) != -1) {
        sview0.sviewFrame.getUIManager().hideLabel(RightMenu.RightMenu.id);
    }
}
/* ------------------ 返回上一级底部菜单 ------------------- */
function exitBottomMenu(currentMenu, returnMenu = MainBottomMenu) {
    // 关闭弹出框
    //if (currentMenu.BottomMenu.id != "moveMenu") {
    //    sview0.sviewFrame.getUIManager().removeLabel("confirm-exit");
    //}
    currBottomMenu = returnMenu.BottomMenu.id;
    // 删除当前菜单
    sview0.sviewFrame.getUIManager().removeLabel(currentMenu.BottomMenu.id);
    // 显示上一级菜单
    sview0.sviewFrame.getUIManager().showLabel(returnMenu.BottomMenu.id);
    // 显示右侧菜单
    if (hiddenRightMenu.indexOf(currentMenu.BottomMenu.id) != -1 && hiddenRightMenu.indexOf(returnMenu.BottomMenu.id) == -1) {
        sview0.sviewFrame.getUIManager().showLabel(RightMenu.RightMenu.id);
    }
}
// 打开气泡选择器
function showPopoverSelect(id) {
    var dirs = document.getElementById(id).parentElement.parentElement.parentElement.querySelector(".SView-show");
    if (dirs && id != dirs.id) {
        dirs.classList.remove("SView-show");
        dirs.classList.add("SView-hide");
    }
    if (document.getElementById(id).className.indexOf("SView-hide") > -1) {
        document.getElementById(id).classList.remove("SView-hide");
        document.getElementById(id).classList.add("SView-show");
    } else {
        document.getElementById(id).classList.remove("SView-show");
        document.getElementById(id).classList.add("SView-hide");
    }
}
// 隐藏气泡选择器
function hidePopoverSelect(id) {
    var dirs = document.getElementById(id).parentElement.parentElement.parentElement.querySelector(".SView-show");
    if (dirs && id != dirs.id) {
        dirs.classList.remove("SView-show");
        dirs.classList.add("SView-hide");
    }
}
//切换按钮
function selectImg(id, parentId) {
    var dirs = document.getElementById(id).parentElement.parentElement.children;
    for (var i = 0; i < dirs.length; i++) {
        dirs[i].children[0].style.backgroundColor = "";
    }
    SView.Windows.Button.highLightLabel(id);
    var menu = document.getElementById(parentId);
    var btnImg = menu.getElementsByTagName("img")[0];
    var currentImg = document.getElementById(id).getElementsByTagName("img")[0];
    btnImg.src = currentImg.src;
    btnImg.title = currentImg.title;
    menu.getElementsByClassName("SView-show")[0].classList.add("SView-hide");
    menu.getElementsByClassName("SView-show")[0].classList.remove("SView-show");
}
// 选择移动方向
function selectTranslationDir(id, num) {
    var dirs = document.getElementById(id).parentElement.parentElement.children;
    for (var i = 0; i < dirs.length; i++) {
        dirs[i].children[0].style.backgroundColor = "";
    }
    SView.Windows.Button.highLightLabel(id);
    // 沿平面移动
    if (num == 0) {
        console.log("沿平面移动");
        /* ------------------ 沿平面移动 ------------------ */
    } else if (num == 1) {
        console.log("沿X轴移动");
        /* ------------------ 沿X轴移动 ------------------ */
    } else if (num == 2) {
        console.log("沿Y轴移动");
        /* ------------------ 沿Y轴移动 ------------------ */
    } else if (num == 3) {
        console.log("沿Z轴移动");
        /* ------------------ 沿Z轴移动 ------------------ */
    }
}
// 打开气泡弹窗
function showPopover(className) {
    
}
// 滑块颜色填充
function sliderChange(className) {
    var slider = document.getElementsByClassName(className)[0];
    var min = slider.min;
    var max = slider.max;
    // var step = slider.step;
    var value = slider.value;
    slider.style.backgroundSize = value * 100 / (max - min) + "% 100%";
    // console.log(value);
    // 电脑端
    slider.onmousemove = function () {
        // console.log(this.value);
        slider.style.backgroundSize = this.value * 100 / (max - min) + "% 100%";
    }
    // 手机端
    slider.ontouchmove = function () {
        // console.log('mobile',this.value);
        slider.style.backgroundSize = this.value * 100 / (max - min) + "% 100%";
    }
}

// 快照
function snapShot() {
    console.log("快照");
    /* ------------------ 快照 ------------------ */
}

// 清空批注对象
function clearAnnotates() {
    console.log("清空批注对象")
    /* ------------------ 清空批注对象 ------------------ */
}

// 清空测量对象
function clearMeasurements() {
    console.log("清空测量对象")
    /* ------------------ 清空测量对象 ------------------ */
}

// 清空刨切面
function clearSectionPlanes() {
    console.log("清空刨切面")
    /* ------------------ 清空刨切面 ------------------ */
}

/* -------------------------------- 移动菜单 --------------------------------- */
// 选择移动方向
function selectTranslationDir(className, num) {
    var dirs = document.getElementsByClassName(className);
    var transDir = dirs[num];
    for (var i = 0; i < dirs.length; i++) {
        dirs[i].style.backgroundColor = "";
    }
    btnHighLight(transDir);
    // 沿平面移动
    if (num == 0) {
        console.log("沿平面移动");
        /* ------------------ 沿平面移动 ------------------ */
    } else if (num == 1) {
        console.log("沿X轴移动");
        /* ------------------ 沿X轴移动 ------------------ */
    } else if (num == 2) {
        console.log("沿Y轴移动");
        /* ------------------ 沿Y轴移动 ------------------ */
    } else if (num == 3) {
        console.log("沿Z轴移动");
        /* ------------------ 沿Z轴移动 ------------------ */
    }
}
/* -------------------------------- 批注菜单 --------------------------------- */
//公共命令方法
function commandClickFun(id, commandType, type) {
    if (id && id != "") {
        var dirs = document.getElementById(id).parentElement.parentElement.children;
        for (var i = 0; i < dirs.length; i++) {
            dirs[i].children[0].style.backgroundColor = "";
        }
        SView.Windows.Button.highLightLabel(id);
    }
    let uiManager = sview0.sviewFrame.getUIManager();
    //let command = new [commandType]();
    let commandsManager = sview0.sviewFrame.getCommandsManager();
    if (type) {
        commandsManager.getCommand(commandType).setDistanceMeasureType(type);
    }
    commandsManager.excute(commandType);
}

//文本批注确认事件
function confirmButton(commandType) {
    let commandsManager = sview0.sviewFrame.getCommandsManager();
    commandsManager.getCommand(commandType).confirmButton();
}
//文本批注命令
function selectAnnotateMode(id) {
    //var textAnnotationButton = document.getElementById(id);
    SView.Button.highLightLabel(id);
    let commandsManager = sview0.sviewFrame.getCommandsManager();
    commandsManager.setModule(SView);
    let command = commandsManager.get(SView.Commands.TEXTANNOTATION);
    //let command = new AnnotationTextCommand();
    //commandsManager.add(SView.Commands.TEXTANNOTATION,command);
    let listener = SView.createSViewObject(SView, "AnnotationCommandListener");
    listener.onStart = function () {
        console.log("开始执行批注命令");
    }
    listener.onStateChanged = function (state) {
        console.log("批注当前在步骤" + state);
        if (state === 0) {
            BtnMessageDialog.Message.content = "请选择第一个点";
            sview0.sviewFrame.getUIManager().load(BtnMessageDialog);
        }
        if (state === 1) {
            BtnMessageDialog.Message.content = "请选择第二个点";
            sview0.sviewFrame.getUIManager().load(BtnMessageDialog);
        }
        if (state === 2) {
            sview0.sviewFrame.getUIManager().load(Dialog);
            sview0.sviewFrame.getUIManager().removeLabel(BtnMessageDialog.Message.id);
        }
    }
    listener.onEnd = function () {
        console.log("批注命令执行结束");
    }
    listener.onError = function (error) {
        console.error(error);
    }
    listener.onSuccess = function (command) {
        let annotation = command.getAnnotation();
    }
    command.addListener(listener);
    commandsManager.excute(SView.Commands.TEXTANNOTATION);

    //sview0.sviewFrame.getCommandsManager().exitAll();
    //sview0.sviewFrame.getCommandsManager().setModule(SView);
    //sview0.sviewFrame.getCommandsManager().excute(SView.Commands.TEXTANNOTATION);
}

/* ------------------ 关闭弹窗 ------------------- */
function closeAnnotationDialog(elementId, btnId = null) {
    // 删除相应标签
    sview0.sviewFrame.getUIManager().removeLabel(elementId);
    // 隐藏相应标签
    // sview0.sviewFrame.getUIManager().hideLabel(elementId);
    // 对应按钮取消高亮
    if (btnId != null) {
        SView.Button.highLightLabel(btnId);
    }
    let command = sview0.sviewFrame.getCommandsManager().get(SView.Commands.TEXTANNOTATION);
    command.undo(1);
    //
}
/* ------------------ 创建批注 ------------------- */
function createAnnotation(elementId, btnId = null) {
    let value = document.getElementById(btnId).value;
    // 删除相应标签
    sview0.sviewFrame.getUIManager().removeLabel(elementId);
    // 隐藏相应标签
    // sview0.sviewFrame.getUIManager().hideLabel(elementId);
    // 对应按钮取消高亮
    if (btnId != null) {
        SView.Button.highLightLabel(btnId);
    }
    let command = sview0.sviewFrame.getCommandsManager().get(SView.Commands.TEXTANNOTATION);
    command.textAnnotationStep(null);
}
/* ------------------ 编辑批注 ------------------- */
function eidtAnnotate() {
    MessageDialog.Message.content = "请先选择一个批注对象"
    // 创建提示信息弹出框
    uiLayout.load(MessageDialog);
    setTimeout(function () {
        uiLayout.removeLabel(MessageDialog.Message.id);
    }, 3000)
}
/* ------------------ 确认删除批注 ------------------- */
function deleteAnnotate(elementId) {
    SuccessInfo.ResultDialog.title.content = "删除成功";
    SuccessInfo.ResultDialog.detail.content = "选中批注已成功删除";
    uiLayout.removeLabel(elementId);
    uiLayout.load(SuccessInfo);
    setTimeout(function () {
        uiLayout.removeLabel(SuccessInfo.ResultDialog.id);
    }, 3000)
}
// 选择批注类型
function selectAnnotateMode(className, num) {
    var modes = document.getElementsByClassName(className);
    var annotateMode = modes[num];
    // 所选注释类型高亮
    if (annotateMode.style.backgroundColor != "") {
        annotateMode.style.backgroundColor = ""
    } else {
        for (var i = 0; i < modes.length; i++) {
            modes[i].style.backgroundColor = "";
        }
        btnHighLight(annotateMode);
        // 注释类型选择  doing
        if (num == 0) {
            console.log("文本批注");
            /* ------------------ 文本批注 ------------------ */
        } else if (num == 1) {
            console.log("序号批注");
            /* ------------------ 序号批注 ------------------ */
        } else if (num == 2) {
            console.log("模型名称批注");
            /* ------------------ 模型批注 ------------------ */
        }
    }
}
// 编辑批注
function eidtAnnotate() {
    console.log("编辑批注");
    /* ------------------ 编辑批注 ------------------ */
}
// 删除批注
function deleteAnnotate() {
    console.log("删除批注");
    /* ------------------ 删除批注 ------------------ */
}
// 撤销手势批注
function undoGestureNote() {
    console.log("撤销手势批注");
    /* ------------------ 撤销手势批注 ------------------ */
}
// 确认手势批注
function confirmGestureNote() {
    console.log("确认手势批注");
    /* ------------------ 确认手势批注 ------------------ */
}

/* -------------------------------- 动画菜单 --------------------------------- */
// 动画播放
var playSliderBar = null; // 动画播放进度条计时器
function animationPlay(className) {
    var button = document.getElementsByClassName(className)[0];
    var img = button.getElementsByTagName("img")[0];
    var play = "button_ani_play.png";
    var playRoute = "./images/moreMenu/animation/button_ani_play.png";
    // var pause = "button_ani_pause.png";
    var pauseRoute = "./images/moreMenu/animation/button_ani_pause.png";
    var slider = document.getElementsByClassName("animationSlider")[0];
    imgRoute = img.src.split('/');
    imgSrc = imgRoute[imgRoute.length - 1];

    // 更新进度条
    function refreshSliderBar() {
        if (slider.value < 100) {
            slider.value = parseInt(slider.value) + 1;
            slider.style.backgroundSize = slider.value * 100 / (slider.max - slider.min) + "% 100%";
        }
    }
    // 替换按钮图标
    if (imgSrc == play) {
        // 播放动画
        /* ------------------ 动画播放 ------------------- */
        img.src = pauseRoute;
        if (playSliderBar != null) {
            playSliderBar = null
            playSliderBar = setInterval(refreshSliderBar, 1000);
        } else {
            playSliderBar = setInterval(refreshSliderBar, 1000);
        }
    } else {
        // 暂停动画
        /* ------------------ 动画暂停 ------------------- */
        img.src = playRoute;
        clearInterval(playSliderBar);
        playSliderBar = null
    }
}
// 动画快进
function fastForward() {
    // 更新进度条
    /* ------------------ 动画快进 ------------------- */
    var slider = document.getElementsByClassName("animationSlider")[0];
    if (slider.value < 90) {
        slider.value = parseInt(slider.value) + 10;
        slider.style.backgroundSize = slider.style.backgroundSize = slider.value * 100 / (slider.max - slider.min) + "% 100%";
    }
}
// 动画快退
function fastBackward() {
    // 更新进度条
    /* ------------------ 动画快退 ------------------- */
    var slider = document.getElementsByClassName("animationSlider")[0];
    if (slider.value > 10) {
        slider.value = parseInt(slider.value) - 10;
        slider.style.backgroundSize = slider.style.backgroundSize = slider.value * 100 / (slider.max - slider.min) + "% 100%";
    }
}
// 动画循环播放
function playInLoop() {
    var loopCheckbox = document.getElementById("playLoop");
    if (loopCheckbox.checked) {
        console.log("动画循环播放");
        /* ------------------ 动画循环播放 ------------------- */
    } else {
        console.log("动画单次播放");
        /* ------------------ 动画单次播放 ------------------- */
    }
}
// 动画倍速播放
function playSpeed() {
    var speed = document.getElementById("playSpeed");
    console.log(speed.value,"倍速播放");
    /* ------------------ 动画倍速播放 ------------------- */
}
// 动画自动漫游模式
function playAutoWalking() {
    var walking = document.getElementById("autoWalking");
    if (walking.checked) {
        console.log("自动漫游模式开启");
        /* ------------------ 自动漫游模式 ------------------- */
    } else {
        console.log ("自动漫游模式关闭")
        /* ------------------ 非自动漫游模式 ------------------- */
    }
}

/* -------------------------------- 测量菜单 --------------------------------- */
// 选择测量类型
function selectMeasure(className, num) {
    var allMethods = document.getElementsByClassName(className);
    var method = allMethods[num];
    // 若已选中，取消选中
    if (method.style.backgroundColor != "") {
        method.style.backgroundColor = ""
    } else {
        for (var i = 0; i < allMethods.length; i++) {
            allMethods[i].style.backgroundColor = "";
        }
        btnHighLight(method);
        // 距离测量
        if (className == "disMeasureMethod") {
            if (num == 0) {
                console.log("点点测量");
                /* ------------------ 点点测量 ------------------ */
            } else if (num == 1){
                console.log("点线测量");
                /* ------------------ 点线测量 ------------------ */
            } else if (num == 2){
                console.log("点面测量");
                /* ------------------ 点面测量 ------------------ */
            } else if (num == 3){
                console.log("线线测量");
                /* ------------------ 线线测量 ------------------ */
            } else if (num == 4){
                console.log("线面测量");
                /* ------------------ 线面测量 ------------------ */
            } else if (num == 5){
                console.log("面面测量");
                /* ------------------ 面面测量 ------------------ */
            } else if (num == 6){
                console.log("厚度");
                /* ------------------ 厚度 ------------------ */
            }
        }
        // 角度测量
        if (className == "angleMeasureMethod") {
            if (num == 0) {
                console.log("线线角度");
                /* ------------------ 线线角度 ------------------ */
            } else if (num == 1){
                console.log("线面角度");
                /* ------------------ 线面角度 ------------------ */
            } else if (num == 2){
                console.log("面面角度");
                /* ------------------ 面面角度 ------------------ */
            }
        }
        // 圆相关测量
        if (className == "circleMeasureMethod") {
            if (num == 0) {
                console.log("弧线创建圆心");
                /* ------------------ 弧线创建圆心 ------------------ */
            } else if (num == 1){
                console.log("三点创建圆心");
                /* ------------------ 三点创建圆心 ------------------ */
            } else if (num == 2){
                console.log("直径");
                /* ------------------ 直径 ------------------ */
            } else if (num == 3){
                console.log("半径");
                /* ------------------ 半径 ------------------ */
            } else if (num == 4){
                console.log("轴距");
                /* ------------------ 轴距 ------------------ */
            } else if (num == 5){
                console.log("圆心距");
                /* ------------------ 圆心距 ------------------ */
            }
        }
        // 属性测量
        if (className == "attriMeasureMethod") {
            if (num == 0) {
                console.log("点");
                /* ------------------ 点属性 ------------------ */
            } else if (num == 1){
                console.log("线");
                /* ------------------ 线属性 ------------------ */
            } else if (num == 2){
                console.log("面");
                /* ------------------ 面属性 ------------------ */
            } else if (num == 3){
                console.log("模型");
                /* ------------------ 模型属性 ------------------ */
            }
        }
    }
}
// 删除测量对象
function deleteMeasurement() {
    console.log("删除测量对象");
    /* ------------------ 删除测量对象 ------------------ */
}

/* -------------------------------- 刨切菜单 --------------------------------- */
// 刨切方向
function setSectionDir(className) {
    var button = document.getElementsByClassName(className)[0];
    btnHighLight(button);
    if (button.style.backgroundColor != "") {
        if (className == "yzSection") {
            console.log("yz面刨切");
            /* ------------------ yz面刨切 ------------------ */
        } else if (className == "xySection") {
            console.log("xy面刨切");
            /* ------------------ xy面刨切 ------------------ */
        } else if (className == "zxSection") {
            console.log("zx面刨切");
            /* ------------------ zx面刨切 ------------------ */
        }
    }
}
// 刨切反向
function sectionReverse(className) {
    var button = document.getElementsByClassName(className)[0];
    btnHighLight(button);
    if (button.style.backgroundColor != "") {
        if (className == "yzSectionReverse") {
            console.log("yz面刨切反向");
            /* ------------------ yz面刨切反向 ------------------ */
        } else if (className == "xySectionReverse") {
            console.log("xy面刨切反向");
            /* ------------------ xy面刨切反向 ------------------ */
        } else if (className == "zxSectionReverse") {
            console.log("zx面刨切反向");
            /* ------------------ zx面刨切反向 ------------------ */
        } else if (className == "allSectionReverse") {
            console.log("所有面刨切反向");
            /* ------------------ 所有面刨切反向 ------------------ */
        } 
    }
}
// 刨切面/刨切盖面显隐
function showSectionPlane(className) {
    var button = document.getElementsByClassName(className)[0];
    btnHighLight(button);
    if (button.style.backgroundColor != "") {
        if (className == "sectionPlane") {
            console.log("刨切面显隐");
            /* ------------------ 刨切面显隐 ------------------ */
        } else if (className == "coverPlane") {
            console.log("盖面显隐");
            /* ------------------ 盖面显隐 ------------------ */
        }
    }
}
// 添加刨切对象
function addSectionPart() {
    console.log("添加刨切对象");
    /* ------------------ 添加刨切对象 ------------------ */
}
// 清空刨切对象
function clearSectionPart() {
    console.log("清空刨切对象");
    /* ------------------ 清空刨切对象 ------------------ */
}

/* -------------------------------- 爆炸菜单 --------------------------------- */
// 爆炸级数设置
function setExplosiveGrade() {
    var grade = document.getElementById("explosiveGrade");
    console.log(grade.value,"爆炸");
    /* ------------------ 爆炸级数设置 ------------------ */
}